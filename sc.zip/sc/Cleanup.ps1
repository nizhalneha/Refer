﻿$ErrorActionPreference = 'silentlycontinue'
$Now = Get-Date
$computername = $env:computername
$TargetFolder1 = "D:\SMTPSink\"
#$TargetFolder2 = "D:\Program Files (x86)\Parallels\Plesk\Mail Servers\Mail Enable\Logging\MTA"
$TargetFolder3 = "C:\Windows\System32\winevt\Logs"
$TargetFolder4 = "C:\Windows\Temp"
$TargetFolder5 = "C:\Program Files (x86)\Parallels\Plesk\tmp"
$TargetFolder6 = "C:\Windows\System32\LogFiles\HTTPERR"
$TargetFolder7 = "C:\Program Files\Microsoft SQL Server\MSSQL1*\MSSQL\Backup\*"
$TargetFolder8 = "D:\Program Files (x86)\Parallels\Plesk\Mail Servers\Mail Enable\Logging\"
$TargetFolder9 = "D:\Program Files (x86)\Parallels\Plesk\Mail Servers\Mail Enable\Queues\temp\*"
$TargetFolder10 = "D:\Program Files (x86)\Parallels\Plesk\Mail Servers\Mail Enable\Bad Mail"
$TargetFolder11 = "C:\assp\logs"
$TargetFolder12 = "C:\scripts\threadedstatslog"
$TargetFolder13 = "C:\assp\debug\"
$TargetFolder14 = "C:\assp\errors\"
$TargetFolder15 = "C:\assp\notspam\"
$TargetFolder16 = "C:\assp\spam\"
$TargetFolder17 = "C:\Program Files (x86)\Parallels\Plesk\PrivateTemp"
$TargetFolder18 = "C:\Program Files (x86)\Parallels\Plesk\tmp\horde"
$TargetFolder19 = "C:\Program Files (x86)\Parallels\Plesk\admin\logs"
$TargetFolder20 = "C:\Program Files (x86)\Parallels\Plesk\PMM\logs"
$TargetFolder21 = "D:\EventLogs\"
$TargetFolder22 = "D:\inetpub\vhosts\$computername.webhostbox.net\httpdocs\windash\assets\app\modSecLogs\logs"
$nagios_logfile = "C:\Program Files\NSClient++\nsclient.log"
$TargetFolder23 = "D:\temp\"
$TargetFolder24 = "C:\Program Files\Microsoft Data Protection Manager\DPM\Temp"
$TargetFolder25 = "D:\SMTPSink\ftpLogs"
$TargetFolder26 = "D:\SMTPSink\netstat"
$TargetFolder27 = "D:\inetpub\vhosts\$computername.webhostbox.net\httpdocs\logs"
$TargetFolder28 = "D:\Program Files (x86)\Parallels\Plesk\Mail Servers\Mail Enable\Scratch"
$TargetFolder29 = "D:\temp\Transcripts"

$LastWrite1 = $Now.AddDays(-30)
$LastWrite2 = $Now.AddDays(-2)
$LastWrite3 = $Now.AddDays(-7)
$LastWrite4 = $Now.AddDays(-90)
$LastWrite5 = $Now.AddDays(-3)
$LastWrite6 = $Now.AddDays(-10)
$LastWrite7 = $Now.AddDays(-360)
$LastWrite8 = $Now.AddDays(-20)


#Create folder if absent
if(!(test-path $TargetFolder26)) {new-item $TargetFolder26 -type directory}

Get-Childitem $TargetFolder1 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
#Get-Childitem $TargetFolder2 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder3 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder4 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite2"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder5 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite2"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder6 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder7 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite2"} | Remove-Item -Recurse -force
#needs to be changed to lastwrite time 2
Get-Childitem $TargetFolder8 -recurse | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite2" -and $_.name -like "*.log"} | Remove-Item -Recurse -force
Get-Item $TargetFolder9 | Where {$_.lastwritetime -le "$LastWrite3"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder10 | Where {!$_.PsIsContainer  -and $_.LastWriteTime -le "$LastWrite3" -and $_.name -like "*.MAI"} | Remove-Item -force
Get-Childitem $TargetFolder11 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder12 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite3"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder13 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite3"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder14 -recurse | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite5"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder15 -recurse | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite5"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder16 -recurse | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite5"} | Remove-Item -Recurse -force
Get-ChildItem $TargetFolder17 | Where {$_.lastwritetime -le "$LastWrite2"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder18 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder19 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder20 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder21 -filter "*Archive-ModSecurity*" | Where {$_.LastWriteTime -le "$LastWrite3"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder22 | Where {$_.LastWriteTime -le "$LastWrite3"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder23 | Where {$_.LastWriteTime -le "$LastWrite1"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder24 | Where {$_.LastWriteTime -le "$LastWrite2"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder25 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite4"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder26 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite1"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder27 | Where {!$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite1"} | Remove-Item -Recurse -force
Get-Childitem $TargetFolder28 | Where {$_.PsIsContainer -and $_.LastWriteTime -le "$LastWrite3" -and $_.name -like "*.MAI" } | remove-item -force -Recurse
Get-ChildItem $TargetFolder29 | Where {$_.lastwritetime -le "$LastWrite8"} | Remove-Item 

$Shell = New-Object -ComObject Shell.Application 
$RecBin = $Shell.Namespace(0xA) 
$RecBin.Items() | %{Remove-Item $_.Path -Recurse -Confirm:$false}

#Cleanup Nagios log file
If (((Get-Item $nagios_logfile ).Length/1MB) -gt 50)
		{
		Try {
			clear-content $nagios_logfile
			}catch{}
		}
		
		
		

# This script simply deletes old records of iis Request
$Results = Get-PasswordDecrypt -type "localMSSQL"
[String]$Username = $Results.username
$Password = $Results.Password.GetNetworkCredential().password
[String]$Hostname = $Results.hostname
[String]$Database = $Results.database
 
$sql_user = $Username
$sql_pwd  = $Password
Add-PSSnapin SqlServerCmdletSnapin100
try
{
	invoke-sqlcmd -query "Delete from [fix].[dbo].[IIS_REQUESTS] WHERE LoadedDateTime < DATEADD(MM, -1, GETDATE())" -serverinstance localhost -database "fix" -user $sql_user -password $sql_pwd -querytimeout ([int]::MaxValue)
	invoke-sqlcmd -Query "use [fix] ; DBCC SHRINKFILE([fix_log], 1)" -ServerInstance localhost -EA stop -database "fix"
}
catch{}

$tempfolder = @("C:\scripts\PSModule","C:\scripts\PyModule","C:\scripts\mailenable_backup","c:\scripts\onyx","D:\MigrationBackup","C:\PleskMigration","c:\scripts\pleskpatching","c:\scripts\patchingplesk","C:\scripts\clamd","C:\scripts\clamd_old","C:\scripts\clamdScan")
foreach($folder in $tempfolder){
	if(test-path $folder){
		[datetime]::Now.ToString() + "Removing folder $folder" | out-file "d:\temp\cleanup.log" -append
		Remove-Item –path $folder -recurse -force
	
	}   
}

### Disabling the below command as per  https://jira.endurance.com/browse/WSH-967 
#Cleanup Deleted Items greater than 30 days #Only for plesk-web1 and md-plesk-web1 #Predeployment Phase

#$current_day = get-date -format {yyMMdd}
#$destination="D:\SmtpSink\MEPurge-$current_day.log"
#$([datetime]::Now).tostring() + ",Starting purging of DeletedItems"  | out-file -Append $destination
#& "c:\scripts\mepurge.exe" ALL 30 DELETED | out-file $destination -append
#$([datetime]::Now).tostring() + ",Completed purging of DeletedItems"  | out-file -Append $destination


#remove krab infection
Remove-KrabInfection -servername md-plesk-web2,plesk-web19,plesk-web1,plesk-web2,plesk-web3,plesk-web4,plesk-web5,plesk-web6,plesk-web7,plesk-web8,plesk-web9,plesk-web10,plesk-web11,plesk-web12,plesk-web13,md-plesk-web1,md-plesk-web2,md-plesk-web3,plesk-web16,plesk-web15,plesk-web16,plesk-web17,plesk-web18,plesk-web20,plesk-web21,plesk-web22,plesk-web23,plesk-web24,plesk-web25,plesk-web26,sdin-pp-wb1,mdin-pp-wb2,md-plesk-web7,md-plesk-web4,md-plesk-web6,bh-plesk-web3,bh-plesk-web4,bhin-pp-wb3,bhus-pp-wb9,mdus-pp-wb12,md-plesk-web9,bh-plesk-web5,mdhk-pp-wb2,bhin-pp-wb4,mdus-pp-wb11,mdus-pp-wb13,bhin-pp-wb2,bh-plesk-web2,md-plesk-web8,bh-plesk-web1,sdin-pp-wb4,bhus-pp-wb7,mdhk-pp-wb3
