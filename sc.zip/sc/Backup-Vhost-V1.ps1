﻿Import-Module Webadministration
$start = get-date
#$sites = get-website | ? {($_.bindings.collection).count -gt 0}
$sites = get-website | ? {$_.bindings.collection.protocol.Contains("http") -and $_.id -ne 1}
#$exceptions = "Default Web Site","sqladmin(default)","PleskControlPanel","MailEnable WebMail","webmail(horde)"
if(!(Test-Path "C:\scripts\vhostrobocopy")){New-Item -Path "C:\scripts\vhostrobocopy" -ItemType Directory -Force | Out-Null}
$info = import-csv c:\scripts\vhostfile.csv | ? {$_.servername -eq $env:COMPUTERNAME}
$backupRootPath = "\\$($info.vhost)\Vhostbackup\$($env:COMPUTERNAME.ToLower())\daily"
if(!(Test-Path "$backupRootPath")) 
{write-host "$backupRootPath is not accessible, exiting from the script" -ForegroundColor Magenta
write-output " $backupRootPath is not accessible, exiting from the script" | out-file -FilePath $log -Append -Force
Exit } 
Else {
write-host "$backupRootPath is accessible,continuing.. " -ForegroundColor Magenta
write-output " $backupRootPath is accessible,continuing.." | out-file -FilePath $log -Append -Force  }
 $TodayDate = Get-Date -Format dd-MM-yyyy
 $Old = Get-ChildItem -Path $backupRootPath | Where-Object {($_.CreationTime -lt (Get-Date).AddDays(-4))} | Sort CreationTime | select -First 1 | Select Name,Fullname,CreationTime,LastwriteTime
 $log = "C:\scripts\vhostrobocopy" + "\" + $TodayDate + ".txt"
 write-host "$backupRootPath `n$TodayDate `n$log" -for Yellow
 write-output "$backupRootPath `n$TodayDate `n$log " | out-file -FilePath $log -Append -Force
if ($old){
write-host "OLD = TRUE" -for Green
write-output "OLD = TRUE " | out-file -FilePath $log -Append -Force
  [bool]$rename = $true
  $backupPath = $old.fullname
  $roboargs = " /E /XF UmbracoTraceLog* /XD *cache* /NFL /NDL /ZB /R:0 /W:0 /MT:32 /e /purge /UNILOG+:$Log "
} else {
write-host "OLD = FALSE" -for Green
write-output "OLD = FALSE " | out-file -FilePath $log -Append -Force
  [bool]$rename = $false
  $backupPath = "$($backupRootPath)\$TodayDate"
  if (!(Test-Path backupRootPath)){ 
  mkdir $backupRootPath
  $roboargs = " /E /XF UmbracoTraceLog* /XD *cache* /NFL /NDL /ZB /R:0 /W:0 /MT:32 /UNILOG+:$Log "
  } 
}
$cc = 1;
$tc = $sites.count
$sites | % {
if ($_.physicalpath -notlike "D:\INETPUB\VHOSTS\*"){
write-host "Skipping $($_.name)" -ForegroundColor Yellow

} else {
Write-Progress -Activity "Backup-vHosts" -Status "$cc of $tc - $($_.name)" -PercentComplete ($cc / $tc * 100)
$cc++
    write-host "$(get-date) : Processing $($_.name)" -ForegroundColor Cyan
    write-output "$(get-date) : Processing $($_.name) " | out-file -FilePath $log -Append -Force
      $source = $_.physicalpath  
      $dest = "$backupPath\$($_.name)"
      $robocopyCmd = " & C:\windows\system32\Robocopy.exe `"$Source`" `"$dest`""      
      $RCmd = $RobocopyCmd + $RoboArgs
      #write-host "$RCmd"
      Invoke-Expression -Command $RCmd
}      
}
if ($rename){
$NewName = $backupRootPath +"\"+ $TodayDate
write-host "Renaming $($old.fullname) -> $($backupRootPath)\$TodayDate" -ForegroundColor Magenta
write-output " Renaming $($old.fullname) -> $($backupRootPath)\$TodayDate" | out-file -FilePath $log -Append -Force
Rename-Item $old.FullName -NewName $NewName -Force

$NewTimestamp = Get-Date

Set-ItemProperty -Path $NewName -Name CreationTime -Value $NewTimestamp
Set-ItemProperty -Path $NewName -Name LastWriteTime -Value $NewTimestamp
if($NewName){Write-output "Found $old.FullName, Updated the recent changes from Vhosts folder and renamed to $Newname, Please verify if you see the $newname folder is missing" | out-file -FilePath $log -Append -Force }
else { Write-output "Unable to modify to $NewName " | out-file -FilePath $log -Append -Force }
}
$end = Get-Date
$time = New-TimeSpan $start $end
write-host "Completed in $($time.Hours):$($time.Minutes):$($time.Seconds)"
write-output "Completed in $($time.Hours):$($time.Minutes):$($time.Seconds)" | out-file -FilePath $log -Append -Force
