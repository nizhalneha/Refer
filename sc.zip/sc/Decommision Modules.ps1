﻿<#
Description: Windows Server Decommission Verification
Version: 1.1
Date: 1/16/2015
Author: 
Syntax: 
.\Decom-Verification.ps1 -Server <server name or full path to file containing server list>
	Examples:
			Server name:
			.\Decom-Verification.ps1 -Server TCHVS0011PA
			.\Decom-Verification.ps1 TCHVS0011PA
			
			File path:
			.\Decom-Verification.ps1 -Server C:\Temp\list.txt
			.\Decom-Verification.ps1 C:\Temp\list.txt
#>

Param(
  [string[]]$ServerName = $(Read-Host "Enter server name or full path to list of servers (eg: c:\temp\list.txt)")
)

if ($ServerName -match "\\") {$Servers = Get-Content -Path $ServerName}
else {$Servers = $ServerName}

$ErrorActionPreference = 'silentlycontinue'
$VerbosePreference = 'continue'

#############
# Pre-Check #
#############

Function Pre-Check {
  Param($Server)
  $Error.Clear()
  
  $DNS = [System.Net.Dns]::GetHostEntry("$Server")
  if ($DNS -eq $null) {return 'Error: Server DNS entry not found.';break}
  $IPAddress = $DNS.AddressList.IPAddressToString | Out-String
  $HostName = $DNS.HostName | Out-String
  
  $Online = Test-Connection -ComputerName $Server -Count 2 -Quiet
  if ($Online -eq $false) {return 'Error: Server Offline.';break}
  
  $Accessible = Test-Path -Path "\\$Server\C$"
  if ($Accessible -eq $false) {return 'Error: Server access denied.';break}
  
  $WMITest = Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem
  if ($WMITest) {$WMIAccess = 'True'}
  else {return 'Error: Server WMI inaccessible.';break}
  
  $ServerHealth = [pscustomobject]@{
    FullyQualifiedDomainName = $HostName;
	IP = $IPAddress;
	Online = $Online;
	Accessible = $Accessible;
	WMI_Accessible = $WMIAccess
  }
  return $ServerHealth
}

#######################
# Physical or Virtual #
#######################
  
Function Get-ServerModel {
  Param($Server)
  $Error.Clear()
  $Model = (Get-WmiObject -ComputerName $Server -Class Win32_ComputerSystem).Model
  if ($Model -eq $null) {return 'Error: Unable to query server model.';break}
  $Serial = (Get-WmiObject -ComputerName $Server -Class Win32_BIOS).SerialNumber
  if ($Serial -eq $null) {return 'Error: Unable to query serial number.';break}
  $ServerModel = [pscustomobject]@{
    Model = $Model;
	SerialNumber = $Serial
  }
  return $ServerModel
}

##################
# Get-HostServer #
##################

Function Get-HostServer {
  Param($Server)
  $Error.Clear()
  $Model = (Get-WmiObject -ComputerName $Server -Class Win32_ComputerSystem).Model
  if ($Model -eq $null) {return 'Error: Unable to query server model.';break}
  if ($Model -match "Virtual") {
    $PhysicalServer = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters").GetValue('PhysicalHostName') | Out-String
	if ($PhysicalServer -eq $null) {$PhysicalServer = 'Error: Query for host server failed.'}
	$HostServer = [pscustomobject]@{
	  HostServer = $PhysicalServer
	}
  }
  else {
    $HostServer = [pscustomobject]@{
	  HostServer = 'Not applicable.'
	}
  }
  return $HostServer
}

############
# Get-DRAC #
############

Function Get-DRAC {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null) {return 'Error: Unable to query Operating System.';break}
  $Model = (Get-WmiObject -ComputerName $Server -Class Win32_ComputerSystem).Model
  if ($Model -eq $null) {return 'Error: Unable to query server model.';break}
  if ($Model -notmatch 'Virtual') {
    $TempPath = 'C:\Temp\DRAC.txt'
	$DracConfigPath = "\\$Server\C$\Temp\DRAC.txt"
    $RacCMD = "cmd /c racadm.exe getniccfg > $TempPath"
    $InvokeWMI = Invoke-WmiMethod -class Win32_process -name Create -ArgumentList $RacCMD -ComputerName $Server
	if ($InvokeWMI.ReturnValue -eq '0') {
	  $i = 1
	  while (((Test-Path $DracConfigPath) -eq $false) -and ($i -le 10)) {sleep -Seconds 3;$i++}
	  $i = 1
	  while (((Get-ChildItem -Path $DracConfigPath).Length -eq 0) -and ($i -le 10)) {sleep 3;$i++}
	  if (((Get-ChildItem -Path $DracConfigPath).Length -ne 0)) {$DracConfigLog = Get-Content $DracConfigPath}
	  else {return 'Error: Unable to generate DRAC configuration log.';break}
	  $IP = ($DracConfigLog | where {$_ -match "\AIP Address\s{1,}=.{1,}"} | Select-String -Pattern "\d{1,}.\d{1,}.\d{1,}.\d{1,}").Matches.Value
	  $Subnet = ($DracConfigLog | where {$_ -match "\ASubnet Mask\s{1,}=.{1,}"} | Select-String -Pattern "\d{1,}.\d{1,}.\d{1,}.\d{1,}").Matches.Value
	  $Gateway = ($DracConfigLog | where {$_ -match "\AGateway\s{1,}=.{1,}"} | Select-String -Pattern "\d{1,}.\d{1,}.\d{1,}.\d{1,}").Matches.Value
	  $DRACConfig = [pscustomobject]@{
	    IP = $IP;
	    Subnet = $Subnet;
	    Gateway = $Gateway
	  }
	  return $DRACConfig
	}
	else {
      $DellNameSpace = Get-WmiObject -ComputerName $Server -Namespace root\CIMV2 -Class "__NAMESPACE" | where {$_.Name -eq 'Dell'}
	  if ($DellNameSpace -eq $null) {return 'Error: Dell wmi namespace not found.';break}
	  $DRACIP = (Get-WmiObject -ComputerName $Server -Namespace ROOT\CIMV2\DELL -Class Dell_RemoteAccessServicePort).AccessInfo | Out-String
	  if ($DRACIP -eq $null) {return 'Error: Unable to query DRAC IP.';break}
	  return $DRACIP
	}
  }
  else {return 'Not applicable.';break}
}

#######################
# Get-OperatingSystem #
#######################

Function Get-OperatingSystem {
  Param($Server)
  $Error.Clear()
  $OperatingSystem = Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem
  if ($OperatingSystem -eq $null) {return 'Error: Unable to query Operating System.';break}
  $OSName = $OperatingSystem.Caption
  $OSVersion = $OperatingSystem.Version
  $OS = [pscustomobject]@{
    Name = $OSName;
	Version = $OSVersion
  }
  return $OS
}

########################
# Get-LocalAdminGroups #
########################

Function Get-LocalAdminGroups {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null) {return 'Error: Unable to query Operating System.';break}
  if ($OSVersion -lt '6.1.7601') {
    $TempPath = 'C:\Temp\AdminGroups.txt'
	$LocalAdminGroupPath = "\\$Server\C$\Temp\AdminGroups.txt"
    $LocalAdminGroup = "cmd /c net localgroup administrators > $TempPath"
    $InvokeWMI = Invoke-WmiMethod -class Win32_process -name Create -ArgumentList $LocalAdminGroup -ComputerName $Server
	if ($InvokeWMI.ReturnValue -eq '0') {
	  $i = 1
	  while (((Test-Path $LocalAdminGroupPath) -eq $false) -and ($i -le 10)) {sleep -Seconds 3;$i++}
	  $i = 1
	  while (((Get-ChildItem -Path $LocalAdminGroupPath).Length -eq 0) -and ($i -le 10)) {sleep 3;$i++}
	  if (((Get-ChildItem -Path $LocalAdminGroupPath).Length -ne 0)) {$LocalAdminGroupLog = Get-Content $LocalAdminGroupPath}
	  else {return 'Error: Unable to generate LocalAdminGroup configuration log.';break}
	  $SecurityGroups = $LocalAdminGroupLog | where {$_ -match "DHC"} | Out-String
	  return $SecurityGroups
	}
	else {return 'Error: Unable to invoke wmi method to query local admin groups.';break}
  }
  else {
    $LocalAdminGroups = Invoke-Command -ComputerName $Server -ScriptBlock {net localgroup administrators}
	if ($LocalAdminGroups -eq $null) {return 'Error: Unable to invoke command method to query local admin groups.';break}
	else {
	  $SecurityGroups = $LocalAdminGroups | where {$_ -match "DHC"} | Out-String
	  return $SecurityGroups
	}
  }
}

##################
# Get-DiskDrives #
##################

Function Get-DiskDrives {
  Param($Server)
  $Error.Clear()
  $Volumes = Get-WmiObject -ComputerName $Server -Class Win32_Volume
  if ($Volumes -eq $null) {return 'Error: Unable to query disk volume info.';break}
  $DiskVolumes = @()
  $Volumes | ForEach-Object {
    $Label = $_.Label  | Out-String
	$Name = $_.Name  | Out-String
	$Capacity = "{0:N2}" -f (($_.Capacity) / 1GB)  | Out-String
	$FreeSpace = "{0:N2}" -f (($_.FreeSpace) / 1GB)  | Out-String
	$Model = ($_.GetRelated('Win32_DiskDrive')).Model | Out-String
	$Volume = [pscustomobject]@{
	  Label = $Label;
	  Name = $Name;
	  Capacity = $Capacity;
	  FreeSpace = $FreeSpace;
	  Model = $Model
	}
	$DiskVolumes += $Volume
	$Label,$Name,$Capacity,$FreeSpace,$Model = $null
  }
  return $DiskVolumes
}

#################
# Get-DiskModel #
#################

Function Get-DiskModel {
  Param($Server)
  $Error.Clear()
  $Models = Get-WmiObject -ComputerName $Server -Class Win32_DiskDrive
  if ($Models -eq $null) {return 'Error: Unable to query disk model';break}
  $DiskModels = @()
  $Models | ForEach-Object {
    $DeviceID = $_.DeviceID | Out-String
	$Caption = $_.Caption | Out-String
	$Size = "{0:N2}" -f (($_.Size) / 1GB) | Out-String
	$Status = $_.Status | Out-String
	$Model = [pscustomobject]@{
	  DeviceID = $DeviceID;
	  Model = $Caption;
	  Size = $Size;
	  Status = $Status
	}
	$DiskModels += $Model
	$DeviceID,$Caption,$Size,$Status,$Model = $null
  }
  return $DiskModels
}

#################
# Get-NICConfig #
#################

Function Get-NICConfig {
  Param($Server)
  $Error.Clear()
  $NICConfigs = Get-WmiObject -ComputerName $Server -Class Win32_NetworkAdapterConfiguration | where {$_.IPAddress}
  if ($NICConfigs -eq $null) {return 'Error: Unable to query NIC configuration.';break}
  $AdapterInfo = Get-WmiObject -ComputerName $Server -Class Win32_NetworkAdapter
  if ($AdapterInfo -eq $null) {return 'Error: Unable to query adapter details';break}
  $ActiveNICs = @()
  $NICConfigs | ForEach-Object {
    $IndexNumber = $_.Index | Out-String
    $Name = ($AdapterInfo | where {$_.Index -eq $IndexNumber}).NetConnectionID | Out-String
	$IP = $_.IPAddress | Out-String
	$Subnet = $_.IPSubnet | Out-String
	$Gateway = $_.DefaultIPGateway | Out-String
	$MAC = $_.MACAddress  | Out-String
	$StatusValue = ($AdapterInfo | where {$_.Index -eq $IndexNumber}).NetConnectionStatus
	$Status = switch ($StatusValue) {
	  0 {'Disconnected'};
	  1 {'Connecting'};
	  2 {'Connected'};
	  3 {'Disconnecting'};
	  4 {'Hardware not present'};
	  5 {'Hardware disabled'};
	  6 {'Hardware malfunction'};
	  7 {'Media disconnected'};
	  8 {'Authenticating'};
	  9 {'Authentication succeeded'};
	  10 {'Authentication failed'};
	  11 {'Invalid address'};
	  12 {'Credentials required'}
	}
	$LoadBalanced = (($Gateway -match ".19\b") -or ($Gateway -match ".18\b"))
	$NIC = [pscustomobject]@{
	  Name = $Name;
	  IPAddress = $IP;
	  SubnetMask = $Subnet;
	  Gateway = $Gateway;
	  MAC = $MAC;
	  LoadBalanced = $LoadBalanced;
	  Status = $Status
	}
	$ActiveNICs += $NIC
	$IndexNumber,$Name,$IP,$Subnet,$Gateway,$MAC,$StatusValue,$Status,$NIC,$LoadBalanced = $null
  }
  return $ActiveNICs
}

####################
# Get-UserProfiles #
####################

Function Get-UserProfiles {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null){return 'Error: Unable to query Operating System version.';break}
  if ($OSVersion -lt '6.0') {
    $SubkeyNames = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList").GetSubKeyNames()
    if ($SubkeyNames -eq $null) {return 'Error: Unable to query registry for user profiles.';break}
	$UserProfiles = @()
	$SubkeyNames | ForEach-Object {
      $Path = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$_").GetValue('ProfileImagePath')
	  #if ($Path -eq $null) {continue}
	  $ProfilePath = [pscustomobject]@{
	    ProfilePath = $Path
	  }
	  $UserProfiles += $ProfilePath
	  $Path,$ProfilePath = $null
    }
	return $UserProfiles
  }
  else {
    $Profiles = Get-WmiObject -ComputerName $Server -Class Win32_UserProfile
	if ($Profiles -eq $null) {return 'Error: Unable to query UserProfile class.';break}
	$UserProfiles = @()
	$Profiles | ForEach-Object {
	  $LocalPath = $_.LocalPath | Out-String
	  $LastUseTime = $_.ConvertToDateTime($_.LastUseTime) | Out-String
	  $UserProfile = [pscustomobject]@{
	    ProfilePath = $LocalPath;
		LastUsed = $LastUseTime
	  }
	  $UserProfiles += $UserProfile
	  $LocalPath,$LastUseTime,$UserProfile = $null
	}
	return $UserProfiles
  }
}

##################
# Get-StartupRun #
##################

Function Get-StartupRun {
  Param($Server)
  $Error.Clear()
  $StartupRun = @()
  
  $Run = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run").GetValueNames()
  if ($Run) {
    $Run | ForEach-Object {
      $Name = $_
	  $Path = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run").GetValue($_)
	  $Process = [pscustomobject]@{
	    Name = $Name;
		Path = $Path
	  }
	  $StartupRun += $Process
	  $Run,$Name,$Path,$Process = $null
	}
  }
  
  $RunOnce = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\RunOnce").GetValueNames()
  if ($RunOnce) {
    $RunOnce | ForEach-Object {
      $Name = $_
	  $Path = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\RunOnce").GetValue($_)
	  $Process = [pscustomobject]@{
	    Name = $Name;
		Path = $Path
	  }
	  $StartupRun += $Process
	  $RunOnce,$Name,$Path,$Process = $null
	}
  }
  
  $RunServices = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\RunServices").GetValueNames()
  if ($RunServices) {
    $RunServices | ForEach-Object {
      $Name = $_
	  $Path = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\RunServices").GetValue($_)
	  $Process = [pscustomobject]@{
	    Name = $Name;
		Path = $Path
	  }
	  $StartupRun += $Process
	  $RunServices,$Name,$Path,$Process = $null
	}
  }
  
  $RunServicesOnce = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\RunServicesOnce").GetValueNames()
  if ($RunServicesOnce) {
    $RunServicesOnce | ForEach-Object {
      $Name = $_
	  $Path = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\RunServicesOnce").GetValue($_)
	  $Process = [pscustomobject]@{
	    Name = $Name;
		Path = $Path
	  }
	  $StartupRun += $Process
	  $RunServicesOnce,$Name,$Path,$Process = $null
	}
  }
  if ($StartupRun.Count -eq 0) {$StartupRun = 'No process found.'}
  return $StartupRun
}

################
# Get-SchTasks #
################

Function Get-SchTasks {
  Param($Server)
  $Error.Clear()
  if ((Test-Path C:\Windows\System32\schtasks.exe) -eq $true) {
    $Tasks = schtasks.exe /Query /s $Server | Out-String
	if ($Tasks -eq $null) {return 'Unable to query scheduled tasks.';break}
	return $Tasks
  }
  else {return 'Schtasks.exe not found.';break}
}

################
# Get-Services #
################

Function Get-Services {
  Param($Server)
  $Error.Clear()
  $Services = Get-WmiObject -ComputerName $Server -Class Win32_Service | where {
    ($_.State -eq "Running") -and 
	($_.PathName -notmatch "svchost") -and 
	($_.PathName -notmatch "lsass.exe") -and 
	($_.PathName -notmatch "vmicsvc.exe") -and 
	($_.PathName -notmatch "spoolsv.exe") -and 
	($_.PathName -notmatch "services.exe") -and 
	($_.PathName -notmatch "csrss.exe") -and 
	($_.PathName -notmatch "vds.exe") -and 
	($_.PathName -notmatch "logon.scr") -and
	($_.PathName -notmatch "winlogon.exe") -and
	($_.PathName -notmatch "wmiprvse.exe") -and
	($_.PathName -notmatch "msdtc.exe") -and
	($_.Pathname -notmatch "smss.exe")
  }
  if ($Services -eq $null) {return 'Error: Unable to query services.';break}
  $RunningServices = @()
  $Services | ForEach-Object {
    $Name = $_.Name | Out-String
	$DisplayName = $_.DisplayName | Out-String
	$Description = $_.Description | Out-String
	$State = $_.State | Out-String
	$StartMode = $_.StartMode | Out-String
	$PathName = $_.PathName | Out-String
	$Service = [pscustomobject]@{
	  DisplayName = $DisplayName;
	  Name = $Name;
	  State = $State;
	  StartMode = $StartMode;
	  Path = $PathName
	  Description = $Description;
	}
	$RunningServices += $Service
	$Name,$DisplayName,$Description,$State,$StartMode,$PathName,$Service = $null
  }
  return $RunningServices
}

#################
# Get-Processes #
#################

Function Get-Processes {
  Param($Server)
  $Error.Clear()
  $Processes = Get-WmiObject -ComputerName $Server -Class Win32_Process | where {
    ($_.ProcessName -ne "System") -and
	($_.ProcessName -ne "System Idle Process") -and
	($_.ProcessName -ne "smss.exe") -and
	($_.ProcessName -ne "wininit.exe") -and
	($_.ProcessName -ne "lsm.exe") -and
	($_.ProcessName -ne "conhost.exe") -and
	($_.ProcessName -ne "taskeng.exe") -and
	($_.ProcessName -ne "dllhost.exe") -and
	($_.ProcessName -ne "vmwp.exe") -and
	($_.ProcessName -ne "LogonUI.exe") -and
	($_.ProcessName -ne "rdpclip.exe") -and
	($_.ProcessName -ne "taskhost.exe") -and
	($_.ProcessName -ne "dwm.exe") -and
	($_.ProcessName -ne "explorer.exe") -and
	($_.ProcessName -ne "mmc.exe") -and
	($_.ProcessName -ne "sppsvc.exe") -and
	($_.ExecutablePath -notmatch "svchost.exe") -and
	($_.ExecutablePath -notmatch "lsass.exe") -and
	($_.ExecutablePath -notmatch "vmicsvc.exe") -and
	($_.ExecutablePath -notmatch "spoolsv.exe") -and
	($_.ExecutablePath -notmatch "services.exe") -and
	($_.ExecutablePath -notmatch "csrss.exe") -and
	($_.ExecutablePath -notmatch "vds.exe") -and
	($_.ExecutablePath -notmatch "logon.scr") -and
	($_.ExecutablePath -notmatch "winlogon.exe") -and
	($_.ExecutablePath -notmatch "wmiprvse.exe") -and
	($_.ExecutablePath -notmatch "msdtc.exe")
  }
  if ($Processes -eq $null) {return 'Unable to query processes.';break}
  $RunningProcesses = @()
  $Processes | ForEach-Object {
    $ProcessName = $_.ProcessName | Out-String
	$ExecutablePath = $_.ExecutablePath | Out-String
	$Process = [pscustomobject]@{
	  ProcessName = $ProcessName;
	  Path = $ExecutablePath
	}
	$RunningProcesses += $Process
	$ProcessName,$ExecutablePath,$Process = $null
  }
  return $RunningProcesses
}

#########################
# Get-InstalledSoftware #
#########################

Function Get-InstalledSoftware {
  Param($Server)
  $Error.Clear()
  $Programs = @()
  $SubKeys1 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall").GetSubKeyNames() | where {$_ -notmatch "KB\d{5,}"}
  $SubKeys1 | ForEach-Object {
    $Key = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$_")
	$DisplayName = $Key.GetValue('DisplayName') | Out-String
	if ($DisplayName) {
	  $Version = $Key.GetValue('DisplayVersion') | Out-String
	  $InstallLocation = $Key.GetValue('InstallLocation') | Out-String
	  $InstallSource = $Key.GetValue('InstallSource') | Out-String
	  $Publisher = $Key.GetValue('Publisher') | Out-String
	  $Software = [pscustomobject]@{
	    Name = $DisplayName;
	    Version = $Version;
	    Publisher = $Publisher
	    InstallLocation = $InstallLocation;
	    InstallSource = $InstallSource
	  }
	  $Programs += $Software
	  $Key,$DisplayName,$Version,$InstallLocation,$InstallSource,$Publisher,$Software = $null
    }
  }
  
  $SubKeys2 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall").GetSubKeyNames() | where {$_ -notmatch "KB\d{5,}"}
  if ($SubKeys2 -ne $null) {
    $SubKeys2 | ForEach-Object {
      $Key = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\$_")
	  $DisplayName = $Key.GetValue('DisplayName') | Out-String
	  if ($DisplayName) {
	    $Version = $Key.GetValue('DisplayVersion') | Out-String
	    $InstallLocation = $Key.GetValue('InstallLocation') | Out-String
	    $InstallSource = $Key.GetValue('InstallSource') | Out-String
	    $Publisher = $Key.GetValue('Publisher') | Out-String
	    $Software = [pscustomobject]@{
	      Name = $DisplayName;
	      Version = $Version;
	      Publisher = $Publisher
	      InstallLocation = $InstallLocation;
	      InstallSource = $InstallSource
	    }
	    $Programs += $Software
	    $Key,$DisplayName,$Version,$InstallLocation,$InstallSource,$Publisher,$Software = $null
      }
    }
  }
  
  $SubKeys3 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Installer\UserData").GetSubKeyNames()
  if ($SubKeys3) {
    foreach ($Key3 in $SubKeys3) {
      $UserDataKeys = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Installer\UserData\$Key3\Products").GetSubKeyNames()
	  $UserDataKeys | ForEach-Object {
	    $InstallProperty = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Installer\UserData\$Key3\Products\$_\InstallProperties")
	    $DisplayName = $InstallProperty.GetValue('DisplayName') | Out-String
	    if ($DisplayName) {
	      $Version = $InstallProperty.GetValue('DisplayVersion') | Out-String
	      $InstallLocation = $InstallProperty.GetValue('InstallLocation') | Out-String
	      $InstallSource = $InstallProperty.GetValue('InstallSource') | Out-String
	      $Publisher = $InstallProperty.GetValue('Publisher') | Out-String
	      $Software = [pscustomobject]@{
	        Name = $DisplayName;
	        Version = $Version;
	        Publisher = $Publisher
	        InstallLocation = $InstallLocation;
	        InstallSource = $InstallSource
	      }
	      $Programs += $Software
	      $UserDataKeys,$InstallProperty,$DisplayName,$Version,$InstallLocation,$InstallSource,$Publisher,$Software = $null
        }
      }
    }
  }
  #Users registry
  $Users = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users',"$Server").GetSubKeyNames()
  
  foreach ($User in $Users) {
    $UserProducts = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users',"$Server").OpenSubKey("$User\Software\Microsoft\Installer\Products").GetSubKeyNames()
    foreach ($Product in $UserProducts) {
      $ProductKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users',"$Server").OpenSubKey("$User\Software\Microsoft\Installer\Products\$Product")
	  $DisplayName = $ProductKey.GetValue('ProductName') | Out-String
	  if ($DisplayName) {
	    $Version = '' | Out-String
	    $InstallLocation = '' | Out-String
	    $InstallSource = '' | Out-String
	    $Publisher = '' | Out-String
	    $Software = [pscustomobject]@{
	      Name = $DisplayName;
	      Version = $Version;
	      Publisher = $Publisher
	      InstallLocation = $InstallLocation;
	      InstallSource = $InstallSource
	    }
	    $Programs += $Software
	    $ProductKey,$DisplayName,$Version,$InstallLocation,$InstallSource,$Publisher,$Software = $null
      }
	  $UserProducts = $null
    }
  }
  
  foreach ($User in $Users) {
    $UninstallKeys = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users',"$Server").OpenSubKey("$User\Software\Microsoft\Windows\CurrentVersion\Uninstall").GetSubKeyNames()
    foreach ($Uninstall in $UninstallKeys) {
      $UninstallKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users',"$Server").OpenSubKey("$User\Software\Microsoft\Windows\CurrentVersion\Uninstall\$Uninstall")
	  $DisplayName = $UninstallKey.GetValue('DisplayName') | Out-String
	  if ($DisplayName) {
	    $Version = $UninstallKey.GetValue('DisplayVersion') | Out-String
	    $InstallLocation = $UninstallKey.GetValue('InstallLocation') | Out-String
	    $InstallSource = $UninstallKey.GetValue('InstallSource') | Out-String
	    $Publisher = $UninstallKey.GetValue('Publisher') | Out-String
	    $Software = [pscustomobject]@{
	      Name = $DisplayName;
	      Version = $Version;
	      Publisher = $Publisher
	      InstallLocation = $InstallLocation;
	      InstallSource = $InstallSource
	    }
	    $Programs += $Software
	    $UninstallKey,$DisplayName,$Version,$InstallLocation,$InstallSource,$Publisher,$Software = $null
      }
	  $UninstallKeys = $null
    }
  }
  #>
  return $Programs
}


########################
# Get Virtual Machines #
########################

Function Get-VirtualMachines {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Caption
  if ($OSVersion -eq $null) {return 'Error: Unable to query Operating System.';break}
  $HyperVisor = (Get-Service -ComputerName $Server | where {$_.Name -eq "Virtual Server" -or $_.Name -eq "VMMS"}).Name
  if ($HyperVisor -eq $null) {return 'Hypervisor service not found.';break}
  $VMs = switch -regex ($OSVersion) {
    2003 {(Get-WmiObject -ComputerName $Server -Namespace root\vm\virtualserver -Class VirtualMachine | where {$_.Name -ne $Server}).Name | Out-String};
	2008 {(Get-WmiObject -ComputerName $Server -Namespace root\virtualization -Class Msvm_ComputerSystem | where {$_.ElementName -ne $Server}).ElementName | Out-String};
	2012 {(Get-WmiObject -ComputerName $Server -Namespace root\virtualization\v2 -Class Msvm_ComputerSystem | where {$_.ElementName -ne $Server}).ElementName | Out-String}
  }
  if (($VMs -eq $null) -or ($VMs -notmatch "\w")) {return 'Found HyperVisor service but unable to query for virtual machines.';break}
  return $VMs
}

######################
# Get-ClusterService #
######################

Function Get-ClusterService {
  Param($Server)
  $Error.Clear()
  $ClusterService = Get-Service -ComputerName $Server -Name Clussvc | where {$_.Status -eq "Running"}
  if ($ClusterService -eq $null) {return 'Cluster service not found.';break}
  else {return 'Cluster service found'}
}

####################
# Get-ClusterNodes #
####################

Function Get-ClusterNodes {
  Param($Server)
  $Error.Clear()
  $ClusterService = Get-Service -ComputerName $Server -Name Clussvc | where {$_.Status -eq "Running"}
  if ($ClusterService -eq $null) {return 'Cluster service not found.';break}
  $ClusterNodes = (Get-WmiObject -ComputerName $Server -Namespace root\MSCluster -Class MSCluster_Node).Name
  if ($ClusterNodes -eq $null) {return 'Error: Unable to query cluster nodes.';break}
  else {return ($ClusterNodes | Out-String)}
}

########################
# Get-ClusterResources #
########################

Function Get-ClusterResources {
  Param($Server)
  $Error.Clear()
  $ClusterService = Get-Service -ComputerName $Server -Name Clussvc | where {$_.Status -eq "Running"}
  if ($ClusterService -eq $null) {return 'Cluster service not found.';break}
  $Resources = Get-WmiObject -ComputerName $Server -Namespace root\MSCluster -Class MSCluster_Resource
  if ($Resources -eq $null) {return 'Error: Unable to query cluster resources.';break}
  $ClusterResources = @()
  $Resources | ForEach-Object {
    $Name = $_.Name
	$Type = $_.Type
	$Description = $_.Description
	$Resource = [pscustomobject]@{
	  Name = $Name;
	  ResourceType = $Type;
	  Description = $Description
	}
	$ClusterResources += $Resource
	$Name,$Type,$Description,$Resource = $null
  }
  return $ClusterResources
}

##################
# Get-FileShares #
##################

Function Get-FileShares {
  Param($Server)
  $Error.Clear()
  $Shares = Get-WmiObject -ComputerName $Server -Class Win32_Share | where {($_.Description -ne "Default Share") -and ($_.Description -ne "Remote IPC") -and ($_.Description -ne "Remote Admin")}
  if ($Shares -eq $null) {
    if ($Error) {return ($Error[0].ToString())}
	else {return 'No user shares found.'}
  }
  else {
    $UserShares = @()
    $Shares | ForEach-Object {
	  $Name = $_.Name
	  $Path = $_.Path
	  $Description = $_.Description
	  
	  $UserShare = [pscustomobject]@{
	    Name = $Name;
		Path = $Path;
		Description = $Description
	  }
	  $UserShares += $UserShare
	  $Name,$Path,$Description = $null
	}
    return $UserShares
  }
}

##########################################
# Check for active/listening connections #
##########################################

Function Get-ActiveConnections {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null) {return 'Error: Unable to query OS version';break}
  elseif ($OSVersion -lt '6.1.7601') {
    $TempFile = 'C:\Temp\Netstat.log'
    $NetStatLogPath = "\\$Server\C$\Temp\Netstat.log"
	if ((Test-Path $NetStatLogPath) -eq $true) {Remove-Item -Path $NetStatLogPath -Force}
    $RunNetStat = "cmd /c c:\windows\system32\netstat.exe -ano > $TempFile"
    $InvokeWMI = Invoke-WmiMethod -class Win32_process -name Create -ArgumentList $RunNetStat -ComputerName $Server
    if ($InvokeWMI.ReturnValue -eq '0') {
	  $i = 1
	  while (($i -le 180) -and (Test-Path $NetStatLogPath) -eq $false) {sleep -Seconds 3;$i++}
      $NetStatLog = Get-Content $NetStatLogPath
	  $i = 1
	  while (($i -le 180) -and ($NetStatLog -eq $null)) {$NetStatLog = Get-Content $NetStatLogPath;$i++}
	}
	elseif ((Test-Path $NetStatLogPath) -eq $true) {$NetStatLog = Get-Content $NetStatLogPath}
    else {return 'Error: NetStat execution failed';break}
  }
  else {
    $NetStatLog = Invoke-Command -ComputerName $Server -ScriptBlock {netstat -ano}
	if ($NetStatLog -eq $null) {return 'Error: Unable to create NetStatLog.';break}
  }
  
  if ($NetStatLog -eq $null) {return 'Error: Unable to create NetStatLog.';break}
  
  #Determine Process IDs
  $Processes = @()
  $ProcessLookup = Get-WmiObject -ComputerName $Server -Class Win32_Process
  if ($ProcessLookup -eq $null) {return 'Error: Process lookup failed.';break}
  $ProcessLookup | ForEach-Object {
    $ProcessID = $_.ProcessID
	$ProcessName = $_.ProcessName
	$Process = [pscustomobject]@{
	  ProcessID = $ProcessID;
	  ProcessName = $ProcessName
	}
	$Processes += $Process
	$ProcessID,$ProcessName,$Process = $null
  }
  
  #Create table for connections
  $ActiveConnections = @()
  $NetStatLog | where {
    $_ -match "Listen" -or
	$_ -match "Established" -or
	$_ -match "Close" -or
	$_ -match "Wait" -or
	$_ -match "Delete" -or
	$_ -match "Last" -or
	$_ -match "Syn" -or
	$_ -match "Unknown"
  } | ForEach-Object {
    $Proto = ($_ | Select-String -Pattern "\w{3}\b").Matches.Value | Out-String
	$IPs = ($_ | Select-String -Pattern "\d{1,}.\d{1,}.\d{1,}.\d{1,}:{0,}\d{1,}\s{1,}\d{1,}.\d{1,}.\d{1,}.\d{1,}:{0,}\d{1,}").Matches.Value
	$LocalAddress = ($IPs | Select-String -Pattern "\A\d{1,}.\d{1,}.\d{1,}.\d{1,}:{0,}\d{1,}").Matches.Value | Out-String
	$ExternalAddress = ($IPs | Select-String -Pattern "\d{1,}.\d{1,}.\d{1,}.\d{1,}:{0,}\d{1,}\Z").Matches.Value | Out-String
	$ExternalIP = ($ExternalAddress | Select-String -Pattern "\d{1,}.\d{1,}.\d{1,}.\d{1,}").Matches.Value
	$ExternalAddressHostName = ([System.Net.Dns]::GetHostEntry($ExternalIP)).HostName | Out-String
    $State = ($_ | Select-String -Pattern "[a-z]{4,}_{0,}[a-z]{0,}\w{0,}").Matches.Value | Out-String
	$ProcessID = ($_ | Select-String -Pattern "\d{1,}\Z").Matches.Value
	$Process = ($Processes | where {$_.ProcessID -eq $ProcessID}).ProcessName | Out-String
	
	$NetworkStatus = [pscustomobject]@{
	  Protocol = $Proto
	  Local_IP = $LocalAddress;
	  External_IP = $ExternalAddress;
	  ExternalHostName = $ExternalAddressHostName
	  State = $State;
	  ProcessName = $Process
	}
	$ActiveConnections += $NetworkStatus
	$IPs,$LocalAddress,$ExternalAddress,$State,$ProcessID,$Process,$NetworkStatus,$Proto,$ExternalIP,$ExternalAddressHostName = $null
  }
  return $ActiveConnections
}

#####################
# Get-LogonSessions #
#####################

Function Get-Sessions {
  Param($Server)
  $Error.Clear()
  [system.Array]$LogonSessions = Get-WmiObject -ComputerName $Server -Class Win32_LogonSession
  if ($LogonSessions -eq $null) {return 'Error: Unable to query logon sessions.';break}
  $Sessions = @()
  $LogonSessions | ForEach-Object {
    $LogonId = $_.LogonId | Out-String
	$User = ($_.GetRelated('Win32_Account')).Name | Out-String
	$ProcessInfo = $_.GetRelated('Win32_Process')
	$ProcessName = $ProcessInfo.Name | Out-String
	$ProcessPath = $ProcessInfo.Path | Out-String
	$LogonType = switch ($_.LogonType) {
	  2 {'Interactive'};
	  3 {'Network'};
	  4 {'Batch'};
	  5 {'Service'};
	  6 {'Proxy'};
	  7 {'Unlock'};
	  8 {'NetworkCleartext'};
	  9 {'NewCredentials'};
	  10 {'RemoteInteractive'};
	  11 {'CachedInteractive'};
	  12 {'CachedRemoteInteractive'};
	  13 {'CachedUnlock'}
	}
	$StartTime = $_.ConvertToDateTime($_.StartTime) | Out-String
	$Session = [pscustomobject]@{
	  SessionID = $LogonId;
	  User = $User
	  SessionType = $LogonType;
	  Started = $StartTime;
	  ProcessName = $ProcessName;
	  ProcessPath = $ProcessPath
	}
	$Sessions += $Session
	$LogonId,$User,$LogonType,$StartTime,$ProcessInfo,$ProcessName,$ProcessPath = $null
  }
  return $Sessions
}


###################################
# Check for IIS Service and Sites #
###################################

Function Get-IIS {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null) {return 'Error: Unable to query OS.';break}
  $WebService = Get-Service -ComputerName $Server | where {$_.Name -match "IIS"}
  if ($WebService -eq $null) {return 'Web service not found.';break}
  if ($OSVersion -gt '6.1.7601') {
    $AddIIS6Compatibility = Invoke-Command -ComputerName $Server -ScriptBlock {Add-WindowsFeature -Name Web-WMI}
	if ($AddIIS6Compatibility.Success -eq $false) {return 'Web service found but unable to query web instances';break}
  }
  [System.Array]$Instances = Get-WmiObject -ComputerName $Server -Authentication PacketPrivacy -Impersonation Impersonate -Namespace root\microsoftiisv2 -Class IISWebVirtualDir
  if ($Instances -eq $null) {return 'Web service found but unable to query virtual directories.';break}
  $WebInstances = @()
  $Instances | ForEach-Object {
    $Name = $_.Name | Out-String
    $Site = [pscustomobject]@{
      Name = $Name;
	}
	$WebInstances += $Site
	$Name,$Comment,$Site = $null
  }
  #$ApplicationPools = $AppPools.Name
  
  return $WebInstances
}

################
# Get-IISPools #
################

Function Get-IISPools {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null) {return 'Error: Unable to query OS.';break}
  $WebService = Get-Service -ComputerName $Server | where {$_.Name -match "IIS"}
  if ($WebService -eq $null) {return 'Web service not found.';break}
  if ($OSVersion -gt '6.1.7601') {
    $AddIIS6Compatibility = Invoke-Command -ComputerName $Server -ScriptBlock {Add-WindowsFeature -Name Web-WMI}
	if ($AddIIS6Compatibility.Success -eq $false) {return 'Web service found but unable to query web instances';break}
  }
  [System.Array]$AppPools = Get-WmiObject -ComputerName $Server -Authentication PacketPrivacy -Impersonation Impersonate -Namespace root\microsoftiisv2 -Class IISApplicationPool
  if ($AppPools -eq $null) {return 'Web service found but unable to query application pool.';break}
  $ApplicationPools = @()
  $AppPools | ForEach-Object {
    $Name = $_.Name | Out-String
    $Site = [pscustomobject]@{
      ApplicationPool = $Name;
	}
	$ApplicationPools += $Site
	$Name,$Site = $null
  }
  return $ApplicationPools
}

################
# Get-ControlM #
################

Function Get-ControlM {
  Param($Server)
  $Error.Clear()
  $ControlMService = Get-Service -ComputerName $Server | where {$_.Name -match "CTMAG"}
  if ($ControlMService -eq $null) {
    if ($Error) {return ($Error[0].ToString());break}
	else {return 'Control-M service not found.';break}
  }
  else {return 'Control-M service found.';break}
}

#############
# Get-MSSQL #
#############

Function Get-MsSQL {
  Param($Server)
  $Error.Clear()
  $MsSQLService = Get-Service -ComputerName $Server | where {$_.Name -match "MSSQL"}
  if ($MsSQLService -eq $null) {
    if ($Error) {return ($Error[0].ToString());break}
	else {return 'MsSQL service not found.';break}
  }
  $ComputerManagementNameSpace = (Get-WmiObject -ComputerName $Server -Namespace root\Microsoft\SqlServer -Class "__NAMESPACE" | where {$_.Name -match "ComputerManagement"}).Name
  $Instances = Get-WmiObject -ComputerName $Server -namespace "root\Microsoft\SqlServer\$ComputerManagementNameSpace" -Class SqlService
  if ($Instances -eq $null) {return 'SQL service found but unable to query instances.';break}
  $SQLInstances = @()
  $Instances | ForEach-Object {
    $DisplayName = $_.DisplayName | Out-String
	$ServiceName = $_.ServiceName | Out-String
	$StartName = $_.StartName | Out-String
	$State = switch ($_.State) {
	  1 {'Stopped'};
	  2 {'Start Pending'};
	  3 {'Stop Pending'};
	  4 {'Running'};
	  5 {'Continue Pending'};
	  6 {'Pause Pending'};
	  7 {'Paused'}
	}
	$Instance = [pscustomobject]@{
	  DisplayName = $DisplayName;
	  ServiceName = $ServiceName;
	  StartName = $StartName;
	  State = $State
	}
	$SQLInstances += $Instance
	$DisplayName,$ServiceName,$StartName,$State,$Instance = $null
  }
  return $SQLInstances
}

###########
# Get-FTP #
###########

Function Get-FTP {
  Param($Server)
  $Error.Clear()
  $OSVersion = (Get-WmiObject -ComputerName $Server -Class Win32_OperatingSystem).Version
  if ($OSVersion -eq $null) {return ($Error[0].ToString());break}
  $FTPService = Get-Service -ComputerName $Server | where {$_.Name -match "FTP"}
  if ($FTPService -eq $null) {
    if ($Error) {return ($Error[0].ToString());break}
	else {return 'FTP service not found.';break}
  }
  if ($OSVersion -gt '6.1.7601') {
    $AddIIS6Compatibility = Invoke-Command -ComputerName $Server -ScriptBlock {Add-WindowsFeature -Name Web-WMI}
	if ($AddIIS6Compatibility.Success -eq $false) {return 'FTP service found but unable to query Virtual Directories.';break}
  }
  $VirtualDirs = Get-WmiObject -ComputerName $Server -Namespace root\microsoftiisv2 -Class IIsFtpVirtualDirSetting
  if ($VirtualDirs -eq $null) {return 'FTP service found but unable to query Virtual Directories.';break}
  $VirtualDirectories = @()
  $VirtualDirs | ForEach-Object {
    $Name = $_.Name | Out-String
	$Path = $_.Path | Out-String
	$Directory = [pscustomobject]@{
	  Name = $Name;
	  Path = $Path
	}
	$VirtualDirectories += $Directory
	$Name,$Path = $null
  }
  return $VirtualDirectories
}

###########
# Get-DFS #
###########

Function Get-DFS {
  Param($Server)
  $Error.Clear()
  $DFSService = Get-Service -ComputerName $Server | where {$_.Name -eq "DFS"}
  if ($DFSService -eq $null) {return 'DFS service not found.';break}
  $DFSTarget = Get-WmiObject -ComputerName $Server -Class Win32_DfsTarget
  if ($DFSTarget -eq $null) {return 'DFS service found but unable to query DFS Targets.';break}
  $DFSTargets = @()
  $DFSTarget | ForEach-Object {
	$ShareName = $_.ShareName | Out-String
	$LinkName = $_.LinkName | Out-String
	$ServerName = $_.ServerName | Out-String
	$Target = [pscustomobject]@{
	  ShareName = $ShareName;
	  LinkName = $LinkName;
	  ServerName = $ServerName
	}
	$DFSTargets += $Target
	$ShareName,$LinkName,$ServerName,$Target = $null
  }
  return $DFSTargets
}

############
# Get-DHCP #
############

Function Get-DHCP {
  Param($Server)
  $Error.Clear()
  $DHCPService = Get-Service -ComputerName $Server | where {$_.Name -eq "DHCPServer"}
  if ($DHCPService -eq $null) {return 'DHCP service not found.';break}
  else {return 'DHCP service found.'}
}

##########
# Get-OU #
##########

Function Get-OU {
  Param($Server)
  $Error.Clear()
  $Domain = ((Get-WmiObject -ComputerName $Server -Class Win32_ComputerSystem).Domain | Select-String -Pattern "\w{2,}").Matches.Value
  if ($Domain -eq $null) {return 'Error: Unable to query for domain name.';break}
  $DomainDN = switch ($Domain) {
    hq {'dc=hq,dc=target,dc=com'};
	dist {'dc=dist,dc=target,dc=com'};
	stores {'dc=stores,dc=target,dc=com'};
	email {'dc=email,dc=target,dc=com'};
	labs {'dc=labs,dc=target,dc=com'};
	ipd2 {'dc=ipd2,dc=target,dc=com'};
	iad2 {'dc=iad2,dc=target,dc=com'};
	corp {'dc=corp,dc=target,dc=com'}
  }
  $ADSearcher = [adsisearcher]"(&(objectCategory=Computer)(name=$Server))"
  $ADSearcher.searchRoot="LDAP://$DomainDN"
  $OU = $ADSearcher.FindOne().Properties.distinguishedname
  return $OU
}

############
# Get-SPNs #
############

Function Get-SPNs {
  Param($Server)
  $Error.Clear()
  $Domain = ((Get-WmiObject -ComputerName $Server -Class Win32_ComputerSystem).Domain | Select-String -Pattern "\w{2,}").Matches.Value
  if ($Domain -eq $null) {return 'Error: Unable to query for domain name.';break}
  $DomainDN = switch ($Domain) {
    hq {'dc=hq,dc=target,dc=com'};
	dist {'dc=dist,dc=target,dc=com'};
	stores {'dc=stores,dc=target,dc=com'};
	email {'dc=email,dc=target,dc=com'};
	labs {'dc=labs,dc=target,dc=com'};
	ipd2 {'dc=ipd2,dc=target,dc=com'};
	iad2 {'dc=iad2,dc=target,dc=com'};
	corp {'dc=corp,dc=target,dc=com'}
  }
  $ADSearcher = [adsisearcher]"(&(objectCategory=Computer)(name=$Server))"
  $ADSearcher.searchRoot="LDAP://$DomainDN"
  $SPNs = $ADSearcher.FindOne().Properties.serviceprincipalname
  return ($SPNs | Out-String)
}

############
# Main Run #
############

foreach ($Server in $Servers) {
  Write-Verbose "Collecting data from $Server..."
  #Nullify Variables
  $Date,$Precheck,$ServerModel,$HostServer,$OperatingSystem,$DiskDrives,$DiskModel,$NICConfig,$DRAC,$UserProfiles,$SchTasks,$Services,$Processes,$InstalledSoftware,$StartupRun,$VMs,$ClusterService,$ClusterNodes,$ClusterResources,$FileShares,$Sessions,$ActiveConnections,$IIS,$ControlM,$SQL,$FTP,$DHCP,$DFS,$OU,$SPN = $null
  
  $Date = Get-Date -Format G
  
  Write-Verbose "-Pre-Check"
  $Precheck = Pre-Check $Server
  if ($Precheck -match 'Error') {"Server Pre-Check failed with`: $Precheck";continue}
  
  Write-Verbose "-Server Model"
  $ServerModel = Get-ServerModel $Server

  Write-Verbose "-Host Server"
  $HostServer = Get-HostServer $Server
  
  Write-Verbose "-Operating System"
  $OperatingSystem = Get-OperatingSystem $Server
  
  Write-Verbose "-Local Admin Groups"
  $LocalAdminGroups = Get-LocalAdminGroups $Server
  
  Write-Verbose "-Disk Drives"
  $DiskDrives = Get-DiskDrives $Server
  
  Write-Verbose "-Disk Model"
  $DiskModel = Get-DiskModel $Server
  
  Write-Verbose "-NIC Configuration"
  $NICConfig = Get-NICConfig $Server

  Write-Verbose "-DRAC Configuration"
  $DRAC = Get-DRAC $Server
  
  Write-Verbose "-User Profiles"
  $UserProfiles = Get-UserProfiles $Server
  
  Write-Verbose "-Scheduled Tasks"
  $SchTasks = Get-Schtasks $Server

  Write-Verbose "-Running Services"
  $Services = Get-Services $Server
  
  Write-Verbose "-Running Processes"
  $Processes = Get-Processes $Server

  Write-Verbose "-Installed Software"
  $InstalledSoftware = Get-InstalledSoftware $Server

  Write-Verbose "-Run on Startup"
  $StartupRun = Get-StartupRun $Server
  
  Write-Verbose "-Virtual Machines"
  $VMs = Get-VirtualMachines $Server
  
  Write-Verbose "-Cluster Service"
  $ClusterService = Get-ClusterService $Server
  
  Write-Verbose "-Cluster Nodes"
  $ClusterNodes = Get-ClusterNodes $Server
  
  Write-Verbose "-Cluster Resources"
  $ClusterResources = Get-ClusterResources $Server
  
  Write-Verbose "-File Shares"
  $FileShares = Get-FileShares $Server

  Write-Verbose "-IISInstances"
  $IIS = Get-IIS $Server

  Write-Verbose "-IISPools"
  $IISPools = Get-IISPools $Server
  
  Write-Verbose "-Control-M"
  $ControlM = Get-ControlM $Server
  
  Write-Verbose "-SQL"
  $SQL = Get-MsSQL $Server
  
  Write-Verbose "-FTP"
  $FTP = Get-FTP $Server
  
  Write-Verbose "-DFS"
  $DFS = Get-DFS $Server
  
  Write-Verbose "-DHCP"
  $DHCP = Get-DHCP $Server
  
  Write-Verbose "-OU"
  $OU = Get-OU $Server
  
  Write-Verbose "-SPN"
  $SPN = Get-SPNs $Server
  
  Write-Verbose "-Logon Sessions"
  $Sessions = Get-Sessions $Server
  
  Write-Verbose "-Active Connections"
  $ActiveConnections = Get-ActiveConnections $Server
  
  if ($Precheck -is [Object[]] -or $Precheck -is [pscustomobject]) {$PrecheckTable = $Precheck | ConvertTo-HTML -Fragment}
  else {$PrecheckTable = $Precheck}
  
  if ($ServerModel -is [Object[]] -or $ServerModel -is [pscustomobject]) {$ServerModelTable = $ServerModel | ConvertTo-HTML -Fragment}
  else {$ServerModelTable = $ServerModel}
  
  if ($HostServer -is [Object[]] -or $HostServer -is [pscustomobject]) {$HostServerTable = $HostServer | ConvertTo-HTML -Fragment}
  else {$HostServerTable = $HostServer}
  
  if ($OperatingSystem -is [Object[]] -or $OperatingSystem -is [pscustomobject]) {$OperatingSystemTable = $OperatingSystem | ConvertTo-HTML -Fragment}
  else {$OperatingSystemTable = $OperatingSystem}
  
  $LocalAdminGroupsTable = $LocalAdminGroups
  
  if ($DiskDrives -is [Object[]] -or $DiskDrives -is [pscustomobject]) {$DiskDrivesTable = $DiskDrives | ConvertTo-HTML -Fragment}
  else {$DiskDrivesTable = $DiskDrives}
  
  if ($DiskModel -is [Object[]] -or $DiskModel -is [pscustomobject]) {$DiskModelTable = $DiskModel | ConvertTo-HTML -Fragment}
  else {$DiskModelTable = $DiskModel}
  
  if ($NICConfig -is [Object[]] -or $NICConfig -is [pscustomobject]) {$NICConfigTable = $NICConfig | ConvertTo-HTML -Fragment}
  else {$NICConfigTable = $NICConfig}

  if ($DRAC -is [Object[]] -or $DRAC -is [pscustomobject]) {$DRACTable = $DRAC | ConvertTo-HTML -Fragment}
  else {$DRACTable = $DRAC}
  
  if ($UserProfiles -is [Object[]] -or $UserProfiles -is [pscustomobject]) {$UserProfilesTable = $UserProfiles | ConvertTo-HTML -Fragment}
  else {$UserProfilesTable = $UserProfiles}
  
  if ($Services -is [Object[]] -or $Services -is [pscustomobject]) {$ServicesTable = $Services | ConvertTo-HTML -Fragment}
  else {$ServicesTable = $Services}
  
  if ($Processes -is [Object[]] -or $Processes -is [pscustomobject]) {$ProcessesTable = $Processes | ConvertTo-HTML -Fragment}
  else {$ProcessesTable = $Processes}
  
  if ($InstalledSoftware -is [Object[]] -or $InstalledSoftware -is [pscustomobject]) {$InstalledSoftwareTable = $InstalledSoftware | ConvertTo-HTML -Fragment}
  else {$InstalledSoftwareTable = $InstalledSoftware}

  if ($StartupRun -is [Object[]] -or $StartupRun -is [pscustomobject]) {$StartupRunTable = $StartupRun | ConvertTo-HTML -Fragment}
  else {$StartupRunTable = $StartupRun}
  
  $VMsTable = $VMs
  
  if ($ClusterService -is [Object[]] -or $ClusterService -is [pscustomobject]) {$ClusterServiceTable = $ClusterService | ConvertTo-HTML -Fragment}
  else {$ClusterServiceTable = $ClusterService}
  
  $ClusterNodesTable = $ClusterNodes
  
  if ($ClusterResources -is [Object[]] -or $ClusterResources -is [pscustomobject]) {$ClusterResourcesTable = $ClusterResources | ConvertTo-HTML -Fragment}
  else {$ClusterResourcesTable = $ClusterResources}

  if ($FileShares -is [Object[]] -or $FileShares -is [pscustomobject]) {$FileSharesTable = $FileShares | ConvertTo-HTML -Fragment}
  else {$FileSharesTable = $FileShares}
  
  if ($Sessions -is [Object[]] -or $Sessions -is [pscustomobject]) {$SessionsTable = $Sessions | ConvertTo-HTML -Fragment}
  else {$SessionsTable = $Sessions}
  
  if ($ActiveConnections -is [Object[]] -or $ActiveConnections -is [pscustomobject]) {$ActiveConnectionsTable = $ActiveConnections | ConvertTo-HTML -Fragment}
  else {$ActiveConnectionsTable = $ActiveConnections}
  
  if ($IIS -is [Object[]] -or $IIS -is [pscustomobject]) {$IISTable = $IIS | ConvertTo-HTML -Fragment}
  else {$IISTable = $IIS}

  if ($IISPools -is [Object[]] -or $IISPools -is [pscustomobject]) {$IISPoolsTable = $IISPools | ConvertTo-HTML -Fragment}
  else {$IISPoolsTable = $IISPools}
  
  if ($ControlM -is [Object[]] -or $ControlM -is [pscustomobject]) {$ControlMTable = $ControlM | ConvertTo-HTML -Fragment}
  else {$ControlMTable = $ControlM}
  
  if ($SQL -is [Object[]] -or $SQL -is [pscustomobject]) {$SQLTable = $SQL | ConvertTo-HTML -Fragment}
  else {$SQLTable = $SQL}
  
  if ($FTP -is [Object[]] -or $FTP -is [pscustomobject]) {$FTPTable = $FTP | ConvertTo-HTML -Fragment}
  else {$FTPTable = $FTP}
  
  if ($DFS -is [Object[]] -or $DFS -is [pscustomobject]) {$DFSTable = $DFS | ConvertTo-HTML -Fragment}
  else {$DFSTable = $DFS}
  
  if ($DHCP -is [Object[]] -or $DHCP -is [pscustomobject]) {$DHCPTable = $DHCP | ConvertTo-HTML -Fragment}
  else {$DHCPTable = $DHCP}
  
  if ($OU -is [Object[]] -or $OU -is [pscustomobject]) {$OUTable = $OU | ConvertTo-HTML -Fragment}
  else {$OUTable = $OU}
  
  $SPNTable = $SPN
  
  $ServerDetailsHead = @"
<head>
<title>$Server</title>
<style>
table tr:nth-child(even) {
  background-color: #eee;
}
table tr:nth-child(odd) {
 background-color:#fff;
}
table th	{
  background-color: black;
  color: white;
}
</style>
</head>
"@
  
  $ServerDetailsBody = @"
<body>
<header>
<h1>$Server</h1>
Date: $Date
</header>
<article>
<pre>
<font size="4"><b>Pre-Check</b></font>
$PrecheckTable
<font size="4"><b>Model/Serial</b></font>
$ServerModelTable
<font size="4"><b>Host Server</b></font>
$HostServerTable
<font size="4"><b>Operating System</b></font>
$OperatingSystemTable
<font size="4"><b>Local Administrator Groups</b></font>
$LocalAdminGroupsTable
<font size="4"><b>Disk Drives</b></font>
$DiskDrivesTable
<font size="4"><b>Disk Model</b></font>
$DiskModelTable
<font size="4"><b>Network Adapter Configuration</b></font>
$NICConfigTable
<font size="4"><b>DRAC Configuration</b></font>
$DRACTable
<font size="4"><b>User Profiles</b></font>
$UserProfilesTable
<font size="4"><b>Running Services</b></font> (Excludes common system services.)
$ServicesTable
<font size="4"><b>Running Processes</b></font> (Excludes common system processes.)
$ProcessesTable
<font size="4"><b>Installed Software</b></font>
$InstalledSoftwareTable
<font size="4"><b>Run on Startup</b></font>
$StartupRunTable
<font size="4"><b>Scheduled Tasks</b></font>
$SchTasks
<font size="4"><b>User/App File Shares</b></font>
$FileSharesTable
<font size="4"><b>IIS Virtual Directories</b></font>
$IISTable
<font size="4"><b>IIS Pools</b></font>
$IISPoolsTable
<font size="4"><b>Control-M Service</b></font>
$ControlMTable
<font size="4"><b>SQL Service</b></font>
$SQLTable
<font size="4"><b>FTP Service</b></font>
$FTPTable
<font size="4"><b>DFS Service</b></font>
$DFSTable
<font size="4"><b>DHCP Service</b></font>
$DHCPTable
<font size="4"><b>Active Directory - Organizational Unit (OU)</b></font>
$OUTable
<font size="4"><b>Active Directory - Service Principal Names (SPNs)</b></font>
$SPNTable
<font size="4"><b>Virtual Machines</b></font>
$VMsTable
<font size="4"><b>Cluster Service</b></font>
$ClusterServiceTable
<font size="4"><b>Cluster Nodes</b></font>
$ClusterNodesTable
<font size="4"><b>Cluster Resources</b></font>
$ClusterResourcesTable
<font size="4"><b>Logon Sessions</b></font>
$SessionsTable
<font size="4"><b>Active Connections</b></font>
$ActiveConnectionsTable
</pre>
</article>
</body>
"@

  ##########
  # Output #
  ##########
  
  if ((Test-Path -Path 'C:\TEMP') -eq $false) {New-Item -Path C:\Temp -ItemType Directory}
  $Outfile = "C:\Temp\$Server.html"
  
  Write-Verbose "Output: $Outfile"
  ConvertTo-Html -Head $ServerDetailsHead -Body $ServerDetailsBody | Out-File $Outfile
  
  $IEPath = "c:\Program Files\Internet Explorer\iexplore.exe"
  if ((Test-Path $IEPath) -eq $true) {
    Write-Verbose "Displaying results..."
    Start-Process -FilePath "c:\Program Files\Internet Explorer\iexplore.exe" -ArgumentList $Outfile
  }
  else {}
}