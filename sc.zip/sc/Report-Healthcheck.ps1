﻿Write-Host "Keep the Servers list under C:\temp\servers.txt " -ForegroundColor Cyan
$Servers = Get-Content "C:\temp\Servers.txt"
$ServerResult = @()
$AvgProcessorPercentage = Get-WmiObject -computername $Server win32_processor | Measure-Object -property LoadPercentage -Average | Select Average
$MemoryUsage = gwmi -Class win32_operatingsystem -computername $Server | Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}
$Cdrivefreespace = Get-WmiObject -Class win32_Volume -ComputerName $Server-Filter "DriveLetter = 'C:'" |Select-object @{Name = "C Drive Free Percentage"; Expression = {“{0:N2}” -f  (($_.FreeSpace / $_.Capacity)*100) } }

$ServerResult += [PSCustomObject] @{ 
        ServerName = "$Server"
        CPULoad = "$($AvgProcessorPercentage.Average)%"
        MemLoad = "$($MemoryUsage.MemoryUsage)%"
        CDrive = "$($Cdrivefreespace.'C Drive Free Percentage')%"
    }


$Outputreport = "<HTML><TITLE> Server Health Report </TITLE>
                     <BODY background-color:peachpuff>
                     <font color =""#99000"" face=""Microsoft Tai le"">
                     <H2> Server Health Report </H2></font>
                     <Table border=1 cellpadding=0 cellspacing=0>
                     <TR bgcolor=gray align=center>
                       <TD><B>Server Name</B></TD>
                       <TD><B>Avrg.CPU Utilization</B></TD>
                       <TD><B>Memory Utilization</B></TD>
                       <TD><B>C Drive Utilizatoin</B></TD></TR>"
                        
    Foreach($Entry in $ServerResult) 
    
        { 
          if(($Entry.CpuLoad) -or ($Entry.memload) -ge "80") 
          { 
            $Outputreport += "<TR bgcolor=red>" 
          } 
          else
           {
            $Outputreport += "<TR>" 
          }
          $Outputreport += "<TD>$($Entry.Servername)</TD><TD align=center>$($Entry.CPULoad)</TD><TD align=center>$($Entry.MemLoad)</TD><TD align=center>$($Entry.Cdrive)</TD></TR>" 
        }
     $Outputreport += "</Table></BODY></HTML>" 
         
 
$Outputreport | out-file C:\Scripts\Test.htm 
Invoke-Expression C:\Scripts\Test.htm