﻿$Header = "Server, KB2775511 Installed, Install Date"
$Outfile = "C:\temp\PowerShell Scripts\Get-KBHotfix\Get-KB2775511.csv"
$Servers = Get-Content "C:\temp\PowerShell Scripts\Get-KBHotfix\list.txt"
Add-Content -Path $Outfile -Value $Header

foreach ($Server in $Servers) {
  
  $KB2775511 = Get-WmiObject -Class Win32_QuickFixEngineering -ComputerName $Server | where {$_.HotFixID -like "KB2775511"}
  $KB2775511InstallDate = $KB2775511.InstalledOn

  if ($KB2775511) {

    $KBExists = "Yes"
    
    Write-Host "$Server already has KB2775511 and was installed on $KB2775511InstallDate"

    Add-Content -Path $Outfile -Value "$Server, $KBExists, $KB2775511InstallDate"

  }

  else {

    $KBExists = "No"
    $KBDateInstalled = "n/a"

    Write-Host $Server does not have KB2775511 installed

    Add-Content -Path $Outfile -Value "$Server, $KBExists, $KBDateInstalled"

  }

}