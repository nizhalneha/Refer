﻿$host1 = Get-Content -Path C:\Temp\Haritest\host.txt
foreach ($host1 in $host1)
{
Invoke-Command -ComputerName $host1 -ScriptBlock{
Write-Host -NoNewLine "HostName: "
Get-CimInstance Win32_OperatingSystem | Select-Object  CSName | ForEach{ $_.CSName }
Write-Host -NoNewLine "OSVersion: "
Get-CimInstance Win32_OperatingSystem | Select-Object  Caption | ForEach{ $_.Caption }
Write-Host -NoNewline "CPUCores: "
Get-wmiobject win32_processor | Select-Object NumberOfCores | ForEach{ $_.NumberOfCores}
Write-Host -NoNewline "Memory: "
Get-WmiObject win32_computersystem | Select-Object TotalPhysicalMemory | ForEach{[math]::round($_.TotalPhysicalMemory /1GB)}
Write-Host -NoNewline "DiskPartition: "
Get-WmiObject -class win32_logicaldisk | Select-Object -Property DeviceID, @{L='FreeSpaceGB';E={"{0:N2}" -f ($_.FreeSpace /1GB)}},@{L="Capacity";E={"{0:N2}" -f ($_.Size/1GB)}} | ft -AutoSize
}
}
