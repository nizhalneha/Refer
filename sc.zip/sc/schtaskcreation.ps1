﻿$Action = New-ScheduledTaskAction -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -Argument "-NonInteractive -NoLogo -NoProfile -File c:\scripts\DPMReportscleanup.ps1'"
$Trigger = New-ScheduledTaskTrigger -weekly -At '3AM' -DaysOfWeek Sunday 
$Task = New-ScheduledTask -Action $Action -Trigger $Trigger -Settings (New-ScheduledTaskSettingsSet)
$Task | Register-ScheduledTask -TaskName 'DPMReportcleanup' -User 'public\administrator' -Password 'W6g4;XHM6%4#:"Fm&aQY'


$Trigger= New-ScheduledTaskTrigger -At 6PM -Daily
$User= "NT AUTHORITY\SYSTEM"
$Action= New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NonInteractive -NoLogo -NoProfile -File C:\scripts\IISLOGparser\IISLOGPARSER-V1.ps1"
Register-ScheduledTask -TaskName "IILOGparser" -Trigger $Trigger -User $User -Action $Action 

C:\scripts\CheckHackerFiles\C4HF\CheckForHackerFiles.exe --version

& 'C:\CheckFiles\New Versions\C4HF-new\C4HF\CheckForHackerFiles.exe' --version

$tasks = Get-ScheduledTask; foreach ( $task in $tasks ) {Write-output $task $task.Actions | out-file D:\Temp\schtask.txt -Append }

Get-WmiObject Win32_Process -Filter "name = 'firefox.exe'" | Select-Object CommandLine