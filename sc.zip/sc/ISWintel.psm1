﻿<#
#############################################################################################################
NAME: ISWintel.psm1 (PowerShell Module)

AUTHOR: ISWintel
Version: 2.4
 
DATE  : 12/5/2013

COMMENT: This is a PowerShell Module with multi-purpose functions for the ISWintel Team.
 
Function List: (Updated 11/6/2013 by Jason.Vue)

Function: Get-ClusterResourceOwner <Server or .txt file with list> (Hyper-V Hosts only)
Purpose: Lists all cluster resources and the node that owns them

Function: Get-ClusterResourceStatus <Server or .txt file with list> (Hyper-V Hosts only)
Purpose: Lists all cluster resources and the node that owns them

Function: Get-ClusterNetwork <Server or .txt file with list> (Hyper-V Hosts only)
Purpose: Lists NICs for cluster network

Function: Get-VMHost <Server or .txt file with list> (VMs only)
Purpose: Lists the physical host for a Virtual Machine

Function: Get-DriveSpace <Server or .txt file with list>
Purpose: Lists all available drives, their capacity and free space

Function: Get-ServerHealth <Server or .txt file with list>
Purpose: Lists Server Online status, Uptime, and Pending Reboot (True/False)

Function: Reboot-Server <Server or .txt file with list>
Purpose: Restarts server

Function: Get-VM <Server or .txt file with list> (Hyper-V Hosts only)
Purpose: Retrieves Virtual Machines on a Hyper-V Host (from node level, not cluster level)

Function: Shutdown-VM <Server or .txt file with list> (VMs only)
Purpose: Shuts down a Hyper-V Guest

Function: Get-UserProfilePath <UserID> <Server or .txt file with list>
Purpose: Queries server to see if user profile exists
Examples: 
    Get-UserProfilePath z001322 TCHVS0011PA
    Get-UserProfilePath z001322 c:\temp\serverlist.txt
    
Function: Get-ServerHardwareHealth <Server>
Purpose: Retrieves health status of hardware components

Function: Fix-WinRM <Server>
Purpose: Enables WinRM Listener ports on each IP on server. Run this if remote PowerShell commands are not working on the server.

Function: Get-HardwareDriverVersions <Server>
Purpose: Retrieves all hardware components and their driver/firmware version(s)

Function: Get-ClusterNodes <Server>
Purpose: Retrieves all Nodes that are part of the Cluster

Function Get-VMStartShutdownAction <Server or list>
Purpose: Retrieves Recovery, Shutdown, and Startup actions for VM from Hyper-V level

Function: Get-ServerFreeMemory <Server or list>
Purpose: Retrieves current free physical memory from server

Function: Get-InstalledSoftware <Server or list>
Purpose: Gets list of all registered software/applications that are installed on the OS. (Similar to viewing add/remove programs)

Function: Get-CTXSession <UserID>
Purpose: Retrieves Citrix Session(s) for UserID

Function: Get-ServerPerformance
Purpose: Retrieves processor time, processor queue length, available memory, pages out /sec, average disk sec/transfer, average disk queue length, and NIC output queue length
 
 #############################################################################################################
#>




##############################
##                          ##
## Get-ClusterResourceOwner ##
##                          ##
##############################

Function Get-ClusterResourceOwner {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Hyper-V HostName or Path to list of Host Servers (Example: C:\Temp\HostServers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  foreach ($Server in $Servers) {
    Get-WmiObject -Namespace root\MSCluster -Class MSCluster_NodeToActiveResource -ComputerName $Server -Impersonation Impersonate -Authentication PacketPrivacy | Format-Table -AutoSize -Wrap -Property `
    @{Name='ClusterResource';Expression={
      $Resource = [String]$_.PartComponent
      $Resource.Replace("MSCluster_Resource.Name=`"","").Replace("`"","")}},
    @{Name='Current Owner';Expression={
      $Owner = [String]$_.GroupComponent
      $Owner.Replace("MSCluster_Node.Name=`"","").Replace("`"","")}}
  }
}


###############################
##                           ##
## Get-ClusterResourceStatus ##
##                           ##
###############################

  Function Get-ClusterResourceStatus {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Hyper-V HostName or Path to list of Host Servers (Example: C:\Temp\HostServers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  foreach ($Server in $Servers) {
    Get-WmiObject -Namespace root\MSCluster -Class MSCluster_Resource -ComputerName $Server -Impersonation Impersonate -Authentication PacketPrivacy | Format-Table -AutoSize -Wrap -Property `
    @{Name='ClusterResource';Expression={$_.Name}},
    @{Name='State';Expression={
      if ($_.State -eq "-1") {"StateUnknown"}
      elseif ($_.State -eq "0") {"Inherited"}
      elseif ($_.State -eq "1") {"Initializing"}
      elseif ($_.State -eq "2") {"Online"}
      elseif ($_.State -eq "3") {"Offline"}
      elseif ($_.State -eq "4") {"Failed"}
      elseif ($_.State -eq "128") {"Pending"}
      elseif ($_.State -eq "129") {"Online Pending"}
      elseif ($_.State -eq "130") {"Offline Pending"}}
    }
  }
}
  
########################
##                    ##
## Get-ClusterNetwork ##
##                    ##
########################

Function Get-ClusterNetwork($ClusterName) {
Get-WmiObject -Namespace root\MSCluster -Class MSCluster_NetworkInterface -ComputerName $ClusterName -Impersonation Impersonate -Authentication PacketPrivacy | Sort-Object Network -Descending | FT Name, Address, Adapter, Network, Node
}


################
##            ##
## Get-VMHost ##
##            ##
################

Function Get-VMHost($Server) {
[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters").GetValue('PhysicalHostName')
}


####################
##                ##
## Get-DriveSpace ##
##                ##
####################

Function Get-DriveSpace {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter HostName or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }
  
  foreach ($Server in $Servers) {
    Get-WmiObject -Class Win32_Volume -ComputerName $Server | Format-Table -AutoSize -Wrap -Property `
    @{Name = 'HostName'; Expression = {$_.__SERVER}},
    @{Name = 'DriveLetter'; Expression = {$_.Name}},
    @{Name = 'VolumeCapacity'; Expression = {"{0:N2}" -f ($_.Capacity / 1GB)}},
    @{Name = 'FreeSpace'; Expression = {"{0:N2}" -f ($_.FreeSpace / 1GB)}},
    @{Name = 'PercentFree'; Expression = {"{0:P2}" -f ($_.FreeSpace / $_.Capacity)}}    
  }
}


######################
##                  ##
## Get-ServerHealth ##
##                  ##
######################

Function Get-ServerHealth($Server) {
 
Function Get-PendingReboot
{
[CmdletBinding()]
param(
	[Parameter(Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
	[Alias("CN","Computer")]
	[String[]]$ComputerName="$env:COMPUTERNAME",
	[String]$ErrorLog
	)

Begin
	{
		# Adjusting ErrorActionPreference to stop on all errors, since using [Microsoft.Win32.RegistryKey]
        # does not have a native ErrorAction Parameter, this may need to be changed if used within another
        # function.
		$TempErrAct = $ErrorActionPreference
		$ErrorActionPreference = "Stop"
	}#End Begin Script Block
Process
	{
		Foreach ($Computer in $ComputerName)
			{
				Try
					{
						# Setting pending values to false to cut down on the number of else statements
						$PendFileRename,$Pending,$SCCM = $false,$false,$false
                        
                        # Setting CBSRebootPend to null since not all versions of Windows has this value
                        $CBSRebootPend = $null
						
						# Querying WMI for build version
						$WMI_OS = Get-WmiObject -Class Win32_OperatingSystem -Property BuildNumber, CSName -ComputerName $Computer

						# Making registry connection to the local/remote computer
						$RegCon = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]"LocalMachine",$Computer)
						
						# If Vista/2008 & Above query the CBS Reg Key
						If ($WMI_OS.BuildNumber -ge 6001)
							{
								$RegSubKeysCBS = $RegCon.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\").GetSubKeyNames()
								$CBSRebootPend = $RegSubKeysCBS -contains "RebootPending"
									
							}#End If ($WMI_OS.BuildNumber -ge 6001)
							
						# Query WUAU from the registry
						$RegWUAU = $RegCon.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\")
						$RegWUAURebootReq = $RegWUAU.GetSubKeyNames()
						$WUAURebootReq = $RegWUAURebootReq -contains "RebootRequired"
						
						# Query PendingFileRenameOperations from the registry
						$RegSubKeySM = $RegCon.OpenSubKey("SYSTEM\CurrentControlSet\Control\Session Manager\")
						$RegValuePFRO = $RegSubKeySM.GetValue("PendingFileRenameOperations",$null)
						
						# Closing registry connection
						$RegCon.Close()
						
						# If PendingFileRenameOperations has a value set $RegValuePFRO variable to $true
						If ($RegValuePFRO)
							{
								$PendFileRename = $true

							}#End If ($RegValuePFRO)

						# Determine SCCM 2012 Client Reboot Pending Status
						# To avoid nested 'if' statements and unneeded WMI calls to determine if the CCM_ClientUtilities class exist, setting EA = 0
						$CCMClientSDK = $null
                        $CCMSplat = @{
                            NameSpace='ROOT\ccm\ClientSDK'
                            Class='CCM_ClientUtilities'
                            Name='DetermineIfRebootPending'
                            ComputerName=$Computer
                            ErrorAction='SilentlyContinue'
                            }
                        $CCMClientSDK = Invoke-WmiMethod @CCMSplat
						If ($CCMClientSDK)
                            {
                                If ($CCMClientSDK.ReturnValue -ne 0)
							        {
								        Write-Warning "Error: DetermineIfRebootPending returned error code $($CCMClientSDK.ReturnValue)"
                            
							        }#End If ($CCMClientSDK -and $CCMClientSDK.ReturnValue -ne 0)

						        If ($CCMClientSDK.IsHardRebootPending -or $CCMClientSDK.RebootPending)
							        {
								        $SCCM = $true

							        }#End If ($CCMClientSDK.IsHardRebootPending -or $CCMClientSDK.RebootPending)

                            }#End If ($CCMClientSDK)
                        Else
                            {
                                $SCCM = $null

                            }                        
                        
                        # If any of the variables are true, set $Pending variable to $true
						If ($CBSRebootPend -or $WUAURebootReq -or $SCCM -or $PendFileRename)
							{
								$Pending = $true

							}#End If ($CBS -or $WUAU -or $PendFileRename)
							
						# Creating Custom PSObject and Select-Object Splat
                        $SelectSplat = @{
                            Property=('Computer','CBServicing','WindowsUpdate','CCMClientSDK','PendFileRename','PendFileRenVal','RebootPending')
                            }
						New-Object -TypeName PSObject -Property @{
								Computer=$WMI_OS.CSName
								CBServicing=$CBSRebootPend
								WindowsUpdate=$WUAURebootReq
								CCMClientSDK=$SCCM
								PendFileRename=$PendFileRename
                                PendFileRenVal=$RegValuePFRO
								RebootPending=$Pending
								} | Select-Object @SelectSplat

					}#End Try

				Catch
					{
						Write-Warning "$Computer`: $_"
						
						# If $ErrorLog, log the file to a user specified location/path
						If ($ErrorLog)
							{
								Out-File -InputObject "$Computer`,$_" -FilePath $ErrorLog -Append

							}#End If ($ErrorLog)
							
					}#End Catch
					
			}#End Foreach ($Computer in $ComputerName)
			
	}#End Process
	
End
	{
		# Resetting ErrorActionPref
		$ErrorActionPreference = $TempErrAct
	}#End End
	
}#End Function
   
$Servers = switch ($Server -notlike "*\*") {
  $True {$Server; break}
  $False {Get-Content $Server; break}
  }

$ErrorActionPreference = 'silentlycontinue'
#$Outfile = ".\ServerHealth{0:MMddyy-HHmm}.log" -f (Get-Date)
#$Header = "Server `t OnlineStatus `t Uptime `t RebootPending" | Out-File $Outfile

foreach ($Server in $Servers) {

  #Check server online status
  $DNS = [System.Net.Dns]::GetHostEntry($Server)

  if ($DNS) {
    $Ping = New-Object System.Net.NetworkInformation.Ping
    $Status = $Ping.Send($Server).Status
    if ($Status -eq "Success") {
      $OnlineStatus = 'Online'
    }

    elseif ($Status -eq "TimedOut") {
      $OnlineStatus = 'Offline'
    }
  }
  elseif (!$DNS) {
    $OnlineStatus = 'Hostname invalid'
  }
  
  #Get Uptime
  $Date = Get-Date
  $OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $Server
  $LastBootUpTime = $OperatingSystem.ConvertToDateTime($OperatingSystem.LastBootUpTime)
  $Days = ($Date - $LastBootUpTime).Days
  $Hours = ($Date - $LastBootUpTime).Hours
  $Minutes = ($Date - $LastBootUpTime).Minutes
  $Seconds = ($Date - $LastBootUpTime).Seconds

  $Uptime = "$Days Day(s), $Hours Hour(s), $Minutes Minute(s), $Seconds Second(s)"
  
  $PendingReboot = Get-PendingReboot $Server
  $RebootPending = $PendingReboot.RebootPending
    
  Write-Host $Server `t $OnlineStatus `t Uptime: $Uptime `t RebootPending: $RebootPending

  #"$Server `t $OnlineStatus `t $Uptime `t $RebootPending" | Out-File $Outfile -Append
  
  #Nullify Variables
  $OperatingSystem, $Date, $Days, $hours, $Minutes, $Seconds, $Uptime, $LastBootUpTime, $CBSRebootPend, $WUAURebootReq, $SCCM, $PendFileRename, $RebootPending, $DNS, $Status, $OnlineStatus = $null
  }
}


###################
##               ##
## Reboot-Server ##
##               ##
###################

Function Reboot-Server {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter HostName or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }
  
  foreach ($Server in $Servers) {
    Write-Host "Initiating Reboot on $Server..."
    Restart-Computer $Server -Force
  }
}


############
##        ##
## Get-VM ##
##        ##
############

Function Get-VM {
  [CmdletBinding()]
  Param (  
    [string]$HostServer = $(Read-Host "Please enter Hyper-V HostName or Path to list of Host Servers (Example: C:\Temp\HostServers.txt)")
  )

  $HostServers = switch ($HostServer -notlike "*\*") {
    $True {$HostServer; break}
    $False {Get-Content $HostServer; break}
    }

  foreach ($HostServer in $HostServers) {
  
    $ComputerSystem, $VirtualMachines = $null
    $ComputerSystem = Get-WmiObject -Namespace root\virtualization -Class Msvm_ComputerSystem -ComputerName $HostServer

    $VirtualMachines = $ComputerSystem | Format-Table -AutoSize -Wrap -Property `
    @{Name='VirtualMachine';Expression={$_.ElementName}}, `
    @{Name='State';Expression={
      if ($_.EnabledState -eq "2") {"Running"}
      elseif ($_.EnabledState -eq "3") {"Off"}
      elseif ($_.EnabledState -eq "0") {"Unknown"}
      elseif ($_.EnabledState -eq "32768") {"Paused"}
      elseif ($_.EnabledState -eq "32769") {"Saved"}
      elseif ($_.EnabledState -eq "32770") {"Starting"}
      elseif ($_.EnabledState -eq "32773") {"Saving"}
      elseif ($_.EnabledState -eq "32774") {"Stopping"}
      elseif ($_.EnabledState -eq "32776") {"Pausing"}
      elseif ($_.EnabledState -eq "32777") {"Resuming"}
      elseif ($_.EnabledState -eq $null) {"NoReturnValue - Check VM/Host"}}},
    @{Name='HealthState';Expression={  
      if ($_.HealthState -eq "5") {"Ok"}
      elseif ($_.HealthState -eq "20") {"Major Failure"}
      elseif ($_.HealthState -eq "25") {"Critical Failure"}}},
    @{Name='OperationalStatus';Expression={
      if ($_.OperationalStatus -eq "2") {"Ok"}
      elseif ($_.OperationalStatus -eq "3") {"Degraded"}
      elseif ($_.OperationalStatus -eq "5") {"Predictive Failure"}
      elseif ($_.OperationalStatus -eq "10") {"Stopped"}
      elseif ($_.OperationalStatus -eq "11") {"In Service"}
      elseif ($_.OperationalStatus -eq "15") {"Dormant"}
      elseif ($_.OperationalStatus -eq $null) {"NoReturnValue - Check VM/Host"}}},
    @{Name='HostServer';Expression={$_.__SERVER}}

    $VirtualMachines
  }
}


#################
##             ##
## Shutdown-VM ##
##             ##
#################

Function Shutdown-VM {
  [CmdletBinding()]
  Param (    
    [string]$Server = $(Read-Host "Please enter Virtual Machine Name or Path to list of VMs (Example: C:\Temp\VMList.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
    }

  foreach ($Server in $Servers) {
    $PhysicalHost = $null
    $PhysicalHost = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters").GetValue('PhysicalHostName')

    if ($PhysicalHost -is [String]) {
      $ComputerSystem, $VMGuid, $VMState = $null
      $ComputerSystem = Get-WmiObject -Namespace root\virtualization -Class Msvm_ComputerSystem -ComputerName $PhysicalHost
  
      $VMGuid = $ComputerSystem | where {$_.ElementName -like $Server} | Select-Object -ExpandProperty Name
      if ($VMGuid -eq $null) {Write-Warning -Message "Unable to determine GUID for VM $Server, please check $PhysicalHost"; continue}
  
      $VMState = $ComputerSystem | where {$_.ElementName -like $Server} | Select-Object -ExpandProperty EnabledState
      if ($VMState -eq "2") {Write-Host "$Server is currently Running"}
      elseif ($VMState -eq "3") {Write-Host "$Server is currently Turned Off"}
      elseif ($VMState -eq "0") {Write-Warning -Message "$Server is currently in an unknown state"}
      elseif ($VMState -eq "32768") {Write-Host "$Server is currently Paused"}
      elseif ($VMState -eq "32769") {Write-Host "$Server is currently in a Saved State"}
      elseif ($VMState -eq "32770") {Write-Host "$Server is currently Starting"}
      elseif ($VMState -eq "32773") {Write-Host "$Server is currently Saving"}
      elseif ($VMState -eq "32774") {Write-Host "$Server is currently Stopping"}
      elseif ($VMState -eq "32776") {Write-Host "$Server is currently Pausing"}
      elseif ($VMState -eq "32777") {Write-Host "$Server is currently Resuming"}
      elseif ($VMState -eq $null) {Write-Warning -Message "No Return Value for VM State, please check Host: $PhysicalHost server"; continue}
    }

    elseif ($PhysicalHost -eq $null) {
      Write-Warning -Message "Unable to validate Host Server for $Server. Please ensure $Server is a VM or check virtual guest name and try again."
      Continue
    }

    Write-Verbose -Message "Attempting to initiate shutdown for $Server..." -Verbose

    $ShutdownVM, $CurrentUser = $null
    $CurrentUser = whoami
    $Reason = "IS-Wintel Reboot by $CurrentUser"
    $ShutdownVM = (Get-WmiObject -Namespace root\virtualization -Class Msvm_ShutdownComponent -ComputerName $PhysicalHost | where {$_.SystemName -like $VMGuid}).InitiateShutdown($True,$Reason)
    $ShutdownVM | Out-Null

    if ($ShutdownVM.ReturnValue -eq "0") {Write-Host "Shutdown for $Server initiated successfully" `n}
    elseif ($ShutdownVM.ReturnValue -ne "0") {Write-Warning -Message "Shutdown for $Server failed, please check VM state";Write-Host `r; continue}
    elseif ($ShutdownVM -eq $null) {Write-Warning -Message "No ReturnValue for Shutdown request, please check Host: $PhysicalHost and/or Guest: $Server";Write-Host `r; continue}
  }
}


#########################
##                     ##
## Get-UserProfilePath ##
##                     ##
#########################

Function Get-UserProfilePath {
  [CmdletBinding()]
  Param(
    [Parameter(Mandatory=$True,Position=1)]
    [string]$UserProfile = $(Read-Host "Enter UserProfile Name (Example: Z012345)"),

    [Parameter(Mandatory=$True,Position=2)]
    [string]$Server = $(Read-Host "Enter server/workstation name or file path for list of servers (Example: C:\temp\list.txt)")
  )

  $ErrorActionPreference = 'silentlycontinue'

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  #$Header = "Server `t`t UserProfile `t`t ProfilePath"
  $Outfile = ".\Get-UserProfilePath{0:MMddyy-HHmm}.log" -f (Get-Date)
  #$Header | Out-File $Outfile

  foreach ($Server in $Servers) {
    $DNS, $TestAccess, $Match = $null

    $DNS = [System.Net.Dns]::GetHostEntry($Server)
    if (!$DNS) {
      Write-Warning -Message "Unable to resolve server name. Please check name and try again."
      $Match = "Unable to resolve Server name. Please check name and try again."
      "$Server `t $UserProfile `t`t $Match" | Out-File $Outfile -Append
      continue
    }

    $TestAccess = Test-Path "\\$Server\c$"
    if (!$TestAccess) {
      Write-Warning -Message "Unable to access $Server. Please check permissions and/or Server health"
      $Match = "Unable to access Server. Please check permissions and/or Server health."
      "$Server `t $UserProfile `t`t $Match" | Out-File $Outfile -Append
      continue
    }

    $2K8ProfilePath, $2K8ProfileFolders, $2K8ProfileFolderName, $2K3ProfilePath, $2K3ProfileFolders, $2K3ProfileFolderName, $Match = $null

    $2K8ProfilePath = "\\$Server\C$\Users\$UserProfile"
    $2K3ProfilePath = "\\$Server\C$\Documents and Settings\$UserProfile"
    $2K8ProfileFolders = Get-ChildItem -Path "\\$Server\C$\Users" -Force | where {$_.Name -like "*$UserProfile*"}
    $2K3ProfileFolders = Get-ChildItem -Path "\\$Server\C$\Documents and Settings" -Force | where {$_.Name -like "*$UserProfile*"}
    $2K8ProfileFolderName = $2K8ProfileFolders | Select-Object -ExpandProperty FullName
    $2K3ProfileFolderName = $2K3ProfileFolders | Select-Object -ExpandProperty FullName

    if (Test-Path $2K8ProfilePath) {$Match = $2K8ProfilePath}
    elseif (Test-Path $2K3ProfilePath) {$Match = $2K3ProfilePath}
    elseif ($2K8ProfileFolders) {$Match = $2K8ProfileFolderName}
    elseif ($2K3ProfileFolders) {$Match = $2K3ProfileFolderName}
    else {$Match = "Profile not Found"}

    Write-Host "$Server `t $UserProfile `t $Match"

    "$Server `t $UserProfile `t`t $Match" | Out-File $Outfile -Append
  }
}


##############################
##                          ##
## Get-ServerHardwareHealth ##
##                          ##
##############################

Function Get-ServerHardwareHealth {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Server Name or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  $ErrorActionPreference = 'silentlycontinue'

  foreach ($Server in $Servers) {
    
    #Check DNS to validate Host Name
    $DNS = [System.Net.Dns]::GetHostEntry($Server)
    if (!$DNS) {Write-Warning -Message "Unable to resolve Server name. Please check name and try again.";continue}

    #Test Server Access
    $TestAccess = Test-Path "\\$Server\c$"
    if (!$TestAccess) {Write-Warning -Message "Unable to access $Server. Please check permission(s), online status, and/or Server health.";continue}
    
    #Check to see if Virtual 
    $ServerType = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $Server | Select-Object -ExpandProperty Model
    if ($ServerType -like "*Virtual*") {Write-Warning -Message "$Server is a Virtual Machine. Please enter Physical Servers only.";continue}

    $Chassis = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_Chassis -ComputerName $Server
    if (!$Chassis) {Write-Warning -Message "Unable to access namespace `"root\cimv2\dell`" on $Server. Please check OMSA and/or upgrade OMSA to the latest version.";continue}

    Write-Host `r
    Write-Host "----------------------------------------------------------------"
    Write-Host "Checking for Dell OMSA Version..."

    $OMSA = Get-WmiObject -Namespace root\cimv2\dell -Class Dell_CMApplication -ComputerName $Server | where {$_.Name -like "*OpenManage*"}
    if (!$OMSA){Write-Warning -Message "Error retrieving OMSA Version. Please check OMSA installation."}
    $OMSAVersion = $OMSA | Format-Table -AutoSize -Wrap -Property Name,Version
    $OMSAVersion

    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting Chassis Health..."
    
    #Chassis Health
    $ChassisHealth = $Chassis | Format-Table -AutoSize -Wrap -Property `
    @{Name='Server'; Expression={$_.__SERVER}},
    @{Name='Model'; Expression={$_.Model}},
    @{Name='ESMLogStatus'; Expression={$_.EsmLogStatus}},
    @{Name='FanStatus'; Expression={$_.FanStatus}},
    @{Name='ProcessorStatus'; Expression={$_.ProcStatus}},
    @{Name='MemoryStatus';Expression={$_.MemStatus}},
    @{Name='PowerSupplyStatus'; Expression={$_.PsStatus}},
    @{Name='TempStatus'; Expression={$_.TempStatus}},
    @{Name='VoltStatus'; Expression={$_.VoltStatus}}
    $ChassisHealth

    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting Power Supply Status..."

    #PowerSupply
    $PowerSupply = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_PowerSupply -ComputerName $Server
    if (!$PowerSupply) {$PowerSupplyStatus = Write-Warning -Message "PowerSupply information is unavailable. Please check Server Model or OMSA to see if this component exists."}
    elseif ($PowerSupply) {$PowerSupplyStatus = $PowerSupply | Format-Table -AutoSize -Wrap -Property @{Name='Server';Expression={$_.__SERVER}},Name,Status}
    $PowerSupplyStatus

    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting Processor(s) Status..."

    #Processor(s)
    $Processor = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_Processor -ComputerName $Server
    if (!$Processor) {$ProcessorStatus = Write-Warning -Message "Processor information is unavailable. Please check Server Model or OMSA to see if this component exists."}
    elseif ($Processor) {$ProcessorStatus = $Processor | Format-Table -AutoSize -Wrap -Property @{Name='Server';Expression={$_.__SERVER}},Name,CoreCount,CoreEnabledCount,Status}    
    $ProcessorStatus      

    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting Memory Status..."

    #Memory
    $Memory = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_PhysicalMemory -ComputerName $Server
    if (!$Memory) {$MemoryStatus = Write-Warning -Message "Memory information is unavailable. Please check Server Model or OMSA to see if this component exists."}
    elseif ($Memory) {$MemoryStatus = $Memory | Format-Table -AutoSize -Wrap -Property @{Name='Server';Expression={$_.__SERVER}},Name,@{Name='Capacity (GB)';Expression={[string]$_.Capacity /1GB}},Status}    
    $MemoryStatus

    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting Fan(s) Status..."

    #Cooling Device
    $Fan = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_CoolingDevice -ComputerName $Server
    if (!$Fan) {$FanStatus = Write-Warning -Message "Fan information is unavailable. Please check Server Model or OMSA to see if this component exists."}
    elseif ($Fan) {$FanStatus = $Fan | Format-Table -AutoSize -Wrap -Property @{Name='Server';Expression={$_.__SERVER}},Name,Status}
    $FanStatus

    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting Network Adapter Information..."

    #Network Adapters
    $NIC = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_NetworkPort -ComputerName $Server
    if (!$NIC) {$NICStatus = Write-Warning -Message "Network Adapter information is unavailable. Please check Server Model or OMSA to see if this component exists."}
    elseif ($NIC) {$NICStatus = $NIC | Format-Table -AutoSize -Wrap -Property `
      @{Name='Adapter Description';Expression={$_.OSAdapterDescription}},      
      DriverVersion,
      @{Name='MAC Address';Expression={$_.CurrentMacAddress}},
      IPAddress,
      @{Name='Status';Expression={
        if ($_.NICStatus -like "0") {"Unknown"}
        elseif ($_.NICStatus -like "1") {"Connected"}
        elseif ($_.NICStatus -like "2") {"Disconnected"}
        elseif ($_.NICStatus -like "3") {"Driver Bad"}
        elseif ($_.NICStatus -like "4") {"Driver Disabled"}
        elseif ($_.NICStatus -like "10") {"Hardware Initializing"}
        elseif ($_.NICStatus -like "11") {"Hardware Resetting"}
        elseif ($_.NICStatus -like "12") {"Hardware Closing"}
        elseif ($_.NICStatus -like "13") {"Hardware Not Ready"}}}}

    $NICStatus
    
    Write-Host "----------------------------------------------------------------"
    Write-Host "Collecting DRAC IP..."

    #Drac
    $DRAC = Get-WmiObject -Namespace root\cimv2\dell -Class CIM_RemoteServiceAccessPoint -ComputerName $Server
    if (!$DRAC) {$DRACInfo = Write-Warning -Message "Unable to retrieve DRAC Info. Please check OMSA."}
    elseif ($DRAC) {$DRACInfo = $DRAC | Format-Table -AutoSize -Wrap -Property `
      @{Name='Server';Expression={$_.SystemName}},
      @{Name='Name';Expression={$_.Name}},
      @{Name='DRAC IP Address';Expression={$_.AccessInfo}}}
    
    $DRACInfo

    #Check for PowerShell installation and test WinRM communication        
    $PSpath= "\\$Server\C$\windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    $PowerShellInstalled = Test-Path $PSpath
    
    if ($PowerShellInstalled -like "False") {
      Write-Host "----------------------------------------------------------------"
      Write-Warning -Message "Unable to retrieve health and configuration for DRAC, PERC, Physical Drive(s), and Hardware Error Logs."
      Write-Host "PowerShell is NOT installed." -BackgroundColor Black -ForegroundColor Red
    }

    elseif ($PowerShellInstalled -like "True") {

      $WinRMTest = Test-WSMan $Server
      
      if (!$WinRMTest) {        
        Write-Host "----------------------------------------------------------------"
        Write-Host "WinRM communication failed." -ForegroundColor Red
        Write-Host "Attempting to configure listening port on Server end..."

        psexec -s -h \\$Server winrm.cmd quickconfig -q | Out-Null
        
        $WinRMTest = $null
        $WinRMTest = Test-WSMan $Server

        if (!$WinRMTest) {
        Write-Warning -Message "Unable to retrieve health and configuration for DRAC, PERC, Physical Drive(s), and Hardware Error Logs."
        Write-Host "WinRM communication failed. Please log into server and run `"Winrm quickconfig -q`" and try again." -BackgroundColor Black -ForegroundColor Red
        }

        elseif ($WinRMTest) {Write-Host "Successfully resolved WinRM communication. Continuing script..."}
      }
    }

    if ($PowerShellInstalled -and $WinRMTest) {
      
      Write-Host "----------------------------------------------------------------"
      Write-Host "Collecting DRAC NIC Configuration..." `n

      #Additional DRAC Properties
      $DracNICCfg = Invoke-Command -ComputerName $Server -ScriptBlock {Racadm getniccfg}
      if (!$DracNICCfg) {$DracNICCfg = Write-Warning -Message "Unable to retrieve additional DRAC NIC Configs. Please check OMSA or WinRM health."}
      elseif ($DracNICCfg) {$DracNICCfg}

      Write-Host `r
      Write-Host "----------------------------------------------------------------"
      Write-Host "Collecting DRAC Active Directory Configuration..." `n

      $DracADCfg = Invoke-Command -ComputerName $Server -ScriptBlock {Racadm getconfig -g cfgActiveDirectory}
      if (!$DracADCfg) {$DracADCfg = Write-Warning -Message "Unable to retrieve DRAC AD Config. Please check OMSA or WinRM health."}
      elseif ($DracADCfg) {$DracADCfg}

      Write-Host `r
      Write-Host "----------------------------------------------------------------"
      Write-Host "Collecting Perc Battery Details..." `n

      $PercBattery = Invoke-Command -ComputerName $Server -ScriptBlock {OMReport Storage Battery}
      foreach ($Battery in $PercBattery) {
        if (
        ($Battery -match "Controller") -or
        ($Battery -match "Status\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W") -or
        ($Battery -match "Name") -or
        ($Battery -match "State\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W") -or
        ($Battery -match "Predicted Capacity Status")    
        )
        {Write-Host $Battery}
      }
      
      Write-Host `r
      Write-Host "----------------------------------------------------------------"
      Write-Host "Collecting Physical Drive Details from Storage Controller 0..." `n

      $StorageController0 = Invoke-Command -ComputerName $Server -ScriptBlock {OMREPORT Storage Pdisk Controller=0}

      if (($StorageController0[0] -match "Invalid") -or ($StorageController0[3] -match "No Physical Disks found")) {Write-Warning -Message "Storage Controller 0 does not exist or there are no physical drives present."}
      elseif ($StorageController0[0] -match "Physical Disks") {
        foreach ($Controller0Disk in $StorageController0) {
          if (($Controller0Disk -match "ID\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller0Disk -match "Name\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller0Disk -match "Status\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller0Disk -match "State\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller0Disk -match "Failure Predicted")`
          -or ($Controller0Disk -match "Certified")`
          -or ($Controller0Disk -match "Product ID")`
          -or ($Controller0Disk -match "Serial No.")`
          -or ($Controller0Disk -match "Capacity")`
          -or ($Controller0Disk -match "Vendor ID")) {            
            [System.Array]$Controller0Drives = $Controller0Drives + $Controller0Disk
          }
        }

        foreach ($Controller0Drive in $Controller0Drives) {
          if (
            ($Controller0Drive -match "Critical") -or
            ($Controller0Drive -match "Failed") -or
            ($Controller0Drive -match "Offline") -or
            ($Controller0Drive -match "Failure Predicted" -and $Controller0Drive -match "Yes") -or
            ($Controller0Drive -match "Certified" -and ($Controller0Drive -match "\sNo\s" -or $Controller0Drive -match "\sNo\Z")) -or
            ($Controller0Drive -match "Non-Critical") -or
            ($Controller0Drive -match "Fatal") -or
            ($Controller0Drive -match "Warning") -or
            ($Controller0Drive -match "Degraded")
          )
          {Write-Host $Controller0Drive -ForegroundColor Red}
          else {Write-Host $Controller0Drive}
        }
      }

      Write-Host `r
      Write-Host "----------------------------------------------------------------"
      Write-Host "Collecting Physical Drive Details from Storage Controller 1..." `n

      $StorageController1 = Invoke-Command -ComputerName $Server -ScriptBlock {OMREPORT Storage Pdisk Controller=1}

      if (($StorageController1[0] -match "Invalid") -or ($StorageController1[3] -match "No Physical Disks found")) {Write-Warning -Message "Storage Controller 1 does not exist or there are no physical drives present."}
      elseif ($StorageController1[0] -match "Physical Disks") {
        foreach ($Controller1Disk in $StorageController1) {
          if (($Controller1Disk -match "ID\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller1Disk -match "Name\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller1Disk -match "Status\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller1Disk -match "State\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W\W")`
          -or ($Controller1Disk -match "Failure Predicted")`
          -or ($Controller1Disk -match "Certified")`
          -or ($Controller1Disk -match "Product ID")`
          -or ($Controller1Disk -match "Serial No.")`
          -or ($Controller1Disk -match "Capacity")`
          -or ($Controller1Disk -match "Vendor ID")) {            
            [System.Array]$Controller1Drives = $Controller1Drives + $Controller1Disk
          }
        }

        foreach ($Controller1Drive in $Controller1Drives) {
          if (
            ($Controller1Drive -match "Critical") -or
            ($Controller1Drive -match "Failed") -or
            ($Controller1Drive -match "Offline") -or
            ($Controller1Drive -match "Failure Predicted" -and $Controller1Drive -match "Yes") -or
            ($Controller1Drive -match "Certified" -and ($Controller1Drive -match "\sNo\s" -or $Controller1Drive -match "\sNo\Z")) -or
            ($Controller1Drive -match "Non-Critical") -or
            ($Controller1Drive -match "Fatal") -or
            ($Controller1Drive -match "Warning") -or
            ($Controller1Drive -match "Degraded")
          )
          {Write-Host $Controller1Drive -ForegroundColor Red}
          else {Write-Host $Controller1Drive}
        }
      }

      Write-Host `r
      Write-Host "----------------------------------------------------------------"
      Write-Host "Collecting hardware error logs (most recent 15), this may take a few minutes..."

      $HardwareLog = Invoke-Command -ComputerName $Server -ScriptBlock {Get-EventLog -LogName System -EntryType Error -Source 'Server Administrator' -Newest 15 | Format-Table TimeGenerated,InstanceID,Message -Wrap -AutoSize}
      if (!$HardwareLog) {$HardwareLog = 'No Hardware Error Log(s) Found'}
      $HardwareLog
    }

    $DNS,$TestAccess,$ServerType,$OMSA,$OMSAVersion,$Chassis,$ChassisHealth,$PowerSupply,$PowerSupplyStatus,$Processor,$ProcessorStatus,$Memory,$MemoryStatus,$Fan,$FanStatus,$NIC,$NICStatus,$DRAC,$DRACInfo,$PowerShellInstalled,$WinRMTest,$PercBattery,$DracNICCfg,$DracADCfg,$Battery,$StorageController0,$Controller0Disk,$Controller0Drive,$Controller0Drives,$StorageController1,$Controller1Disk,$Controller1Drives,$Controller1Drive,$HardwareLog = $null
  }
  Write-Host `r
  Write-Host "----------------------------------------------------------------"
  Write-Host "Script Complete" `r
}



###############
##           ##
## Fix-WinRM ##
##           ##
###############

Function Fix-WinRM {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Server Name or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
    }
  
  $ErrorActionPreference = 'silentlycontinue'

  foreach ($Server in $Servers) {
    #Check for PowerShell installation and test WinRM communication
    $PSpath= "\\$Server\C$\windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    $PowerShellInstalled = Test-Path $PSpath

    if ($PowerShellInstalled -like "False") {Write-Warning -Message "PowerShell not installed.Please install PowerShell (2.0 or later) and try again."}
    
    #If PowerShell is installed then test WinRM and run Winrm quickconfig to create listener
    elseif ($PowerShellInstalled -like "True") {
      Write-Host "PowerShell is installed."
      Write-Host "Testing WinRM communication..."
            
      $WinRMTest = Test-WSMan $Server
  
      if ($WinRMTest) {
        Write-Host "WinRM tested successfully."
        Write-Host "Script Complete!"
      }

      elseif (!$WinRMTest) {
        
        Write-Host "WinRM test failed." -ForegroundColor Red
        Write-Host "Attempting to create WinRM listener on $Server using PSEXEC..."

        psexec -s -h \\$Server winrm.cmd quickconfig -q | Out-Null

        Write-Host "Completed."
        Write-Host "Testing WinRM again..."

        $WinRMTest2 = Test-WSMan $Server
          if (!$WinRMTest2) {Write-Warning -Message "WinRM communication is still failing. Please check PowerShell installation, PSEXEC, and/or Server health."}
          elseif ($WinRMTest2) {
            $PSVersion = $WinRMTest2.productversion.Substring(25)
            Write-Host "WinRM tested successfully"
            Write-Host "PowerShell Version is $PSVersion."
            Write-Host "Script Complete!"
          }
      }
    }
  $PowerShellInstalled,$WinRMTest,$WinRMTest2,$PSVersion = $null
  }
}


################################
##                            ##
## Get-HardwareDriverVersions ##
##                            ##
################################

Function Get-HardwareDriverVersions {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Hyper-V HostName or Path to list of Host Servers (Example: C:\Temp\HostServers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  $ErrorActionPreference = 'silentlycontinue'

  foreach ($Server in $Servers) {
        
    $DNS = [System.Net.Dns]::GetHostEntry($Server)
    if (!$DNS) {Write-Warning -Message "Unable to resolve Server name. Please check name and try again.";continue}

    $TestAccess = Test-Path "\\$Server\c$"
    if (!$TestAccess) {Write-Warning -Message "Unable to access $Server. Please check permission(s), online status, and/or Server health.";continue}

    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $Server
    if (!$ComputerSystem) {Write-Warning -Message "Unable to query WMI. Please check server health."}
    elseif ($ComputerSystem) {
      $ServerType = $ComputerSystem | Select-Object -ExpandProperty Model
      if ($ServerType -like "*Virtual*") {Write-Warning -Message "$Server is a Virtual Machine. Please enter physical servers only."}
      else {        
        $CMApplication = Get-WmiObject -Namespace root\cimv2\dell -Class Dell_CMApplication -ComputerName $Server
        if (!$CMApplication) {Write-Warning -Message "Unable to retrieve drivers. Please check OMSA health/install."}
        elseif ($CMApplication) {
          $DriverVersions = $CMApplication | Sort-Object -Property Name -Descending | Format-Table -AutoSize -Wrap -property Name,Version
          
          Write-Host `n
          Write-Host "Server Model: " $ServerType
          $DriverVersions

          $DNS,$TestAccess,$ComputerSystem,$ServerType,$CMApplication,$DriverVersions = $null
        }
      }
    }    
  }
}


######################
##                  ##
## Get-ClusterNodes ##
##                  ##
######################

Function Get-ClusterNodes {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Hyper-V HostName or Path to list of Host Servers (Example: C:\Temp\HostServers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
    }

  foreach ($Server in $Servers) {
    Get-WmiObject -Namespace root\mscluster -Class MSCluster_ClusterToNode -ComputerName $Server -Authentication PacketPrivacy | Sort-Object -Property Dependent | Format-Table -AutoSize -Wrap -Property `
    @{Name='NodeName';Expression={
      $NodeName = [String]$_.Dependent
      $NodeName.Replace("MSCluster_Node.Name=`"","").Replace("`"","")}},
    @{Name='ClusterName';Expression={
      $ClusterName = [String]$_.Antecedent
      $ClusterName.Replace("MSCluster_Cluster.Name=`"","").Replace("`"","")}}
  }
}


###############################
##                           ##
## Get-VMStartShutdownAction ##
##                           ##
###############################

Function Get-VMStartShutdownAction {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Server Name or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  $ErrorActionPreference = 'silentlycontinue'  
  
  foreach ($Server in $Servers) {
    $ModelType = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $Server | Select-Object -ExpandProperty Model
    
    if ($ModelType -notlike "*Virtual*") {Write-Warning -Message "$Server is not a Virtual Machine. Please server and try again."}
    elseif ($ModelType -like "*Virtual*") {
      $HostServer = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters").GetValue('PhysicalHostName')
      
      if ($HostServer -eq $null) {
        Write-Warning -Message "Unable to obtain Host info for $Server. Please check server health."
        $ModelType,$HostServer = $null
        continue
      }

      $VSGlobalSettingData = Get-WmiObject -Namespace Root\Virtualization -Class Msvm_VirtualSystemGlobalSettingData -ComputerName $HostServer | where {$_.ElementName -like $Server}

      $AutomaticRecoveryAction = `
      if ($VSGlobalSettingData.AutomaticRecoveryAction -like "0") {"None"}
      elseif ($VSGlobalSettingData.AutomaticRecoveryAction -like "1") {"Restart"}
      elseif ($VSGlobalSettingData.AutomaticRecoveryAction -like "2") {"Revert to Snapshot"}

      $AutomaticShutdownAction = `
      if ($VSGlobalSettingData.AutomaticShutdownAction -like "0") {"Turn Off"}
      elseif ($VSGlobalSettingData.AutomaticShutdownAction -like "1") {"Save State"}
      elseif ($VSGlobalSettingData.AutomaticShutdownAction -like "2") {"ShutDown"}

      $AutomaticStartupAction = `
      if ($VSGlobalSettingData.AutomaticStartupAction -like "0") {"None"}
      if ($VSGlobalSettingData.AutomaticStartupAction -like "1") {"Restart if Previously Running"}
      if ($VSGlobalSettingData.AutomaticStartupAction -like "2") {"Always Startup"}
    }

    Write-Host Guest: $Server `t Host: $HostServer `t AutoRecoveryAction: $AutomaticRecoveryAction `t AutoShutdownAction: $AutomaticShutdownAction `t AutoStartupAction: $AutomaticStartupAction

    $ModelType,$HostServer,$VSGlobalSettingData,$AutomaticRecoveryAction,$AutomaticShutdownAction,$AutomaticStartupAction = $null
  }
}


##########################
##                      ##
## Get-ServerFreeMemory ##
##                      ##
##########################

Function Get-ServerFreeMemory {
  [CmdletBinding()]
  Param (
    [string]$Server = $(Read-Host "Please enter Server Name or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
    }

  foreach ($Server in $Servers) {  
    $ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $Server
    $TotalPhysicalMemory = "{0:N2}" -f (($ComputerSystem | Select-Object -ExpandProperty TotalPhysicalMemory) /1GB)
  
    $PerfOSMemory = Get-WmiObject -Class Win32_PerfRawData_PerfOS_Memory -ComputerName $Server
    $AvailMemory = "{0:N2}" -f (($PerfOSMemory | Select-Object -ExpandProperty AVailableMBytes) / 1024)

    [decimal]$PercentFreeMemory = "{0:N2}" -f (($AvailMemory / $TotalPhysicalMemory) * 100)    

    Write-Host $Server `t TotalCapacity: $TotalPhysicalMemory GB `t Available: $AvailMemory GB `t PercentAvailable: $PercentFreeMemory `%

    $PerfOSMemory,$AvailMemory,$ComputerSystem,$TotalPhysicalMemory,$PercentFreeMemory = $null
  }
}


###########################
##                       ##
## Get-InstalledSoftware ##
##                       ##
###########################

Function Get-InstalledSoftware {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter Server Name or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {
    $True {$Server; break}
    $False {Get-Content $Server; break}
  }

  foreach ($Server in $Servers) {
    $TestAccess = Test-Path "\\$Server\c$"
    
    if ($TestAccess -like "False") {
    Write-Host "Error: Unable to access $Server. Please check hostname or server health and try again." -ForegroundColor Red    
    $TestAccess = $null
    continue
    }

    $InstalledApps = $null
    $InstalledApps = @()
    $InstalledAppSubKeys = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall").GetSubKeyNames()
    $Apps = $InstalledAppSubKeys | where {$_ -notmatch "KB\d{5,}"}

    foreach ($App in $Apps) {
      $AppSubKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',"$Server").OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$App")
      $DisplayName = $AppSubKey.GetValue("DisplayName")
      
      if ($DisplayName) {
        $DisplayVersion = $AppSubKey.GetValue("DisplayVersion")
        $InstallLocation = $AppSubKey.GetValue("InstallLocation")
        $InstallDate = $AppSubKey.GetValue("InstallDate")
             
        $InstalledAppObj = New-Object -TypeName System.Object
        $InstalledAppObj | Add-Member -MemberType NoteProperty -Name Name -Value $DisplayName
        $InstalledAppObj | Add-Member -MemberType NoteProperty -Name DisplayVersion -Value $DisplayVersion
        $InstalledAppObj | Add-Member -MemberType NoteProperty -Name InstallLocation -Value $InstallLocation
        $InstalledAppObj | Add-Member -MemberType NoteProperty -Name InstallDate -Value $InstallDate
      
        $InstalledApps += $InstalledAppObj
      }
    }
    
    $InstalledApps | Format-Table -Wrap -AutoSize -Property Name,DisplayVersion,InstallDate
        
    $InstalledAppSubKeys,$Apps,$App,$AppSubKey,$DisplayName,$DisplayVersion,$InstallLocation,$InstallDate,$InstalledAppObj, $InstalledApps = $null
  }
}


####################
##                ##
## Get-CTXSession ##
##                ##
####################

Function Get-CTXSession {
  [CmdletBinding()]
  Param (  
    $UserID = $(Read-Host "Please enter the user ID (Eg: DHC\XXXXXX)")
  )
     if (($UserID -eq "$Null") -or ($UserID -notmatch "DHC"))
         {
         Write-Host "Enter the User name in correct format and run the script again"
         }
     else
         {
         $Ses = New-PSSession -ComputerName "TECDCCXA01P"
         Invoke-Command -Session $Ses -ScriptBlock {Add-PSSnapin CITRIX.XenApp.Commands}
         $Session = Invoke-Command -Session $Ses -ScriptBlock {Param($ID) Get-XASession | Where-Object {$_.AccountName -eq $ID} | Ft -Property ServerName, AccountName, BrowserName, State, ApplicationState -AutoSize} -ArgumentList $UserID
         $Session

         if ($Session -ne $Null)
         {
         $Input = Read-Host "Type Yes to proceed with the logoff of User Session or Press enter to exit"
            if ($Input -eq "Yes")
            {
            Invoke-Command -Session $Ses -ScriptBlock {Param($ID) Get-XASession | Where-Object {$_.AccountName -eq $ID} | Stop-XASession} -ArgumentList $UserID
            } 
         }
         Remove-PSSession $Ses
         }
}


###########################
##                       ##
## Get-ServerPerformance ##
##                       ##
###########################

Function Get-ServerPerformance {
  [CmdletBinding()]
  Param (  
    [string]$Server = $(Read-Host "Please enter HostName or Path to list of Servers (Example: C:\Temp\Servers.txt)")
  )

  $Servers = switch ($Server -notlike "*\*") {    
    $True {$Server; break}    
    $False {Get-Content $Server; break}    
  }

  $PerfStatus = $null
  $PerfStatus = @()

  foreach ($Server in $Servers) {
    $Date = Get-Date -Format G
    $TestAccess = Test-Path "\\$Server\c$"

    if ($TestAccess -like "False") {
      Write-Host "Error: Unable to access $Server. Please check hostname or server health and try again." -ForegroundColor Red
      "Server: $Server `t TotalProcessorTime: Error - Server Inaccessible." | Out-File -FilePath "C:\Monitoring\IVRPerfmon\$Server.log" -Append
      $Date,$TestAccess = $null
      continue
    }

    $Counters = @(
    "\Processor(_total)\% Processor Time"
    "\System\Processor Queue Length"    
    "\Memory\Available MBytes"
    "\Memory\Pages Output/sec"
    "\PhysicalDisk(_total)\Avg. Disk sec/Transfer"
    "\PhysicalDisk(_total)\Avg. Disk Queue Length"  
    "\Network Interface(*)\Output Queue Length"
    )

    $CounterQuery = Get-Counter -Counter $Counters -ComputerName $Server

    if ($CounterQuery -eq $null) {
      Write-Warning -Message "Unable to retrieve performance counters. Please check server online/health status."
      #"Server: $Server `t TotalProcessorTime: Error - Unable to retrieve performance counters." | Out-File -FilePath "C:\Monitoring\IVRPerfmon\$Server.log" -Append
      $Date,$TestAccess,$Counters,$CounterQuery = $null
      continue
    }

    elseif ($CounterQuery) {
      $ProcessorTime = "{0:N2}" -f (($CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*processor(_total)\% processor time*"}).CookedValue)
      $ProcessorQueueLength = ($CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*Processor Queue Length*"}).CookedValue
      $AvailMBytes = "{0:N2}" -f (($CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*Available MBytes*"}).CookedValue)
      $PagesOutPutSec = ($CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*Pages Output*"}).CookedValue
      $AvgDiskSecTransfer = "{0:N3}" -f (($CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*Avg. Disk sec/Transfer*"}).CookedValue)
      $AvgDiskQueueLength = "{0:N2}" -f (($CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*Avg. Disk Queue Length*"}).CookedValue)
      $NICOutputQueueLength = $CounterQuery | Select-Object -expandproperty CounterSamples | where {$_.Path -like "*Output Queue Length*"} | Select-Object -ExpandProperty CookedValue

      $PerfObj = New-Object -TypeName System.Object
      $PerfObj | Add-Member -MemberType NoteProperty -Name Date -Value $Date
      $PerfObj | Add-Member -MemberType NoteProperty -Name Server -Value $Server
      $PerfObj | Add-Member -MemberType NoteProperty -Name ProcTime -Value $ProcessorTime
      $PerfObj | Add-Member -MemberType NoteProperty -Name ProcQueueLength -Value $ProcessorQueueLength
      $PerfObj | Add-Member -MemberType NoteProperty -Name AvailMem`(MB`) -Value $AvailMBytes
      $PerfObj | Add-Member -MemberType NoteProperty -Name PagesOut/sec -Value $PagesOutPutSec
      $PerfObj | Add-Member -MemberType NoteProperty -Name AvgDisksec/Transfer -Value $AvgDiskSecTransfer
      $PerfObj | Add-Member -MemberType NoteProperty -Name AvgDiskQueueLength -Value $AvgDiskQueueLength
      $PerfObj | Add-Member -MemberType NoteProperty -Name NIC_OutputQueueLength -Value $NICOutputQueueLength
    }
    
    $PerfStatus += $PerfObj

    $Date,$TestAccess,$Counters,$CounterQuery,$ProcessorTime,$ProcessorQueueLength,$AvailMBytes,$PagesOutPutSec,$AvgDiskSecTransfer,$AvgDiskQueueLength,$NICOutputQueueLength,$PerfObj = $null
  }

  $PerfStatus | Format-Table -AutoSize -Wrap -Property date,server,ProcTime,ProcQueueLength,AvailMem`(MB`),PagesOut/sec,AvgDisksec/Transfer,AvgDiskQueueLength,NIC_OutputQueueLength
  $PerfStatus = $null

}